"""FastAPI 应用入口。

启动：uvicorn app.main:app --host 127.0.0.1 --port 8000
首次启动会在 data/ 下建库并创建 NAVPANEL_ADMIN_USERNAME 指定的账号。
"""

from __future__ import annotations

import hashlib
import re
from contextlib import asynccontextmanager
from html import escape

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from sqlalchemy.orm import Session
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from . import cache, config, site as site_service
from .api import auth, bootstrap, database, groups, icons, items, public, settings
from .api import site as site_api
from .db import SessionLocal, engine, get_db, init_db

APP_VERSION = "0.1.0"

# 首页引用的静态文件：渲染时注入 mtime 版本号，这些文件才敢用 immutable 长缓存
STATIC_ASSETS = ("theme-init.js", "style.css", "app.js")

# 数据库管理是独立页面，自己的 CSS/JS 单独版本化，不混进面板的资源列表
DATABASE_PAGE = "database.html"
DATABASE_PAGE_ASSETS = ("database.css", "database.js")

# React 构建产物：index.html 由 / 直接返回，带 hash 的 app-assets 走 immutable 长缓存
REACT_INDEX = config.REACT_DIST_DIR / "index.html"
REACT_ASSETS_DIR = config.REACT_DIST_DIR / "app-assets"


class CachedStaticFiles(StaticFiles):
    """静态目录按类型下发缓存策略：hash 命名的图标可永久缓存，其余走协商缓存。"""

    def __init__(self, *args, cache_control: str, **kwargs):
        super().__init__(*args, **kwargs)
        self.cache_control = cache_control

    async def get_response(self, path: str, scope):
        response = await super().get_response(path, scope)
        if response.status_code in (200, 304):
            response.headers["Cache-Control"] = self.cache_control
        return response


@asynccontextmanager
async def lifespan(_app: FastAPI):
    cache.init()
    init_db()
    # 图标库只在启动时补登记一次历史缓存文件，之后由抓取/上传接口实时登记
    with SessionLocal() as db:
        icons.sync_library(db)
    yield


class IconAwareGZipMiddleware(GZipMiddleware):
    """图标与背景图已是压缩格式，对其再做 gzip 只会浪费 CPU 并增大体积。"""

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http" and scope["path"].startswith(("/icons/", "/backgrounds/")):
            await self.app(scope, receive, send)
            return
        await super().__call__(scope, receive, send)


# 不暴露交互式文档与 OpenAPI（自托管面板无需对外声明全部接口）
app = FastAPI(
    title="NavPanel",
    description="导航面板最小实现：分组 + 卡片 + 图标抓取（FastAPI + SQLAlchemy）",
    version=APP_VERSION,
    lifespan=lifespan,
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
)

app.add_middleware(IconAwareGZipMiddleware, minimum_size=1024)

# React 版接入：构建产物缺失/不完整时直接启动失败，避免线上返回空白页
if config.FRONTEND == "react":
    if not REACT_INDEX.exists():
        raise RuntimeError(
            f"NAVPANEL_FRONTEND=react，但未找到构建产物 {REACT_INDEX}；"
            "请先在 frontend/ 执行 npm install && npm run build"
        )
    if not REACT_ASSETS_DIR.is_dir():
        raise RuntimeError(f"未找到 React 静态资源目录 {REACT_ASSETS_DIR}")
    app.mount(
        "/app-assets",
        CachedStaticFiles(
            directory=REACT_ASSETS_DIR,
            cache_control="public, max-age=31536000, immutable",
        ),
        name="app-assets",
    )

# 内联主题脚本已抽到 /static/theme-init.js，因此脚本可收紧为仅同源；
# iframe 预览需要允许外站，图片允许外链图标与 data/blob 预览。
_CSP = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob: https: http:; "
    "font-src 'self' data:; "
    "connect-src 'self'; "
    "frame-src 'self' https: http:; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'"
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = _CSP
    return response

app.mount(
    "/static",
    CachedStaticFiles(
        directory=config.WEB_DIR,
        cache_control="public, max-age=31536000, immutable",
    ),
    name="static",
)
app.mount(
    "/icons",
    CachedStaticFiles(
        directory=config.ICON_DIR,
        cache_control="public, max-age=31536000, immutable",
    ),
    name="icons",
)
app.mount(
    "/backgrounds",
    CachedStaticFiles(
        directory=config.BACKGROUND_DIR,
        cache_control="public, max-age=31536000, immutable",
    ),
    name="backgrounds",
)

app.include_router(auth.router)
app.include_router(bootstrap.router)
app.include_router(groups.router)
app.include_router(items.router)
app.include_router(icons.router)
app.include_router(public.router)
app.include_router(settings.router)
app.include_router(site_api.router)
app.include_router(database.router)


@app.get("/api/health", tags=["meta"])
def health() -> dict:
    return {
        "status": "ok",
        "version": APP_VERSION,
        "frontend": config.FRONTEND,
        "public_mode": config.PUBLIC_MODE,
        "database": engine.dialect.name,
        "redis": cache.enabled(),
    }


TITLE_RE = re.compile(r"<title>.*?</title>", re.S)


def _apply_site_title(html: str, db: Session) -> str:
    """把模板里的 <title> 换成站点设置里的标题，首屏就不用等前端脚本；
    数据库异常时保持模板默认标题，不能因此挡住首页。"""
    try:
        title = site_service.read_title(db)
    except Exception:  # noqa: BLE001 - 首页可用性优先
        return html
    return TITLE_RE.sub(f"<title>{escape(title)}</title>", html, count=1)


@app.get("/", include_in_schema=False)
def index(request: Request, db: Session = Depends(get_db)) -> Response:
    """首页：html 版注入静态资源 mtime 版本号；react 版直接返回构建产物。"""
    if config.FRONTEND == "react":
        react_index = config.REACT_DIST_DIR / "index.html"
        html = react_index.read_text(encoding="utf-8")
    else:
        html = (config.WEB_DIR / "index.html").read_text(encoding="utf-8")
        for name in STATIC_ASSETS:
            version = int((config.WEB_DIR / name).stat().st_mtime)
            html = html.replace(f"/static/{name}", f"/static/{name}?v={version}")
    html = _apply_site_title(html, db)
    etag = f'"{hashlib.sha1(html.encode("utf-8")).hexdigest()}"'
    headers = {"Cache-Control": "no-cache", "ETag": etag}
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers=headers)
    return HTMLResponse(html, headers=headers)


@app.get("/database", include_in_schema=False)
def database_page(request: Request) -> Response:
    """数据库管理页：独立的 HTML/CSS/JS，不依赖面板的 style.css / app.js。"""
    page = config.WEB_DIR / DATABASE_PAGE
    if not page.exists():
        raise HTTPException(status_code=404, detail="数据库管理页文件缺失")
    html = page.read_text(encoding="utf-8")
    for name in DATABASE_PAGE_ASSETS:
        asset = config.WEB_DIR / name
        if not asset.exists():
            raise HTTPException(status_code=404, detail=f"数据库管理页资源缺失：{name}")
        version = int(asset.stat().st_mtime)
        html = html.replace(f"/static/{name}", f"/static/{name}?v={version}")
    etag = f'"{hashlib.sha1(html.encode("utf-8")).hexdigest()}"'
    headers = {"Cache-Control": "no-cache", "ETag": etag}
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers=headers)
    return HTMLResponse(html, headers=headers)


@app.get("/favicon.ico", include_in_schema=False)
def favicon() -> Response:
    return Response(status_code=204)