"""口令哈希与 token 签发/校验。

为了不引入 passlib / python-jose 这类额外依赖，这里用标准库实现：
- 口令：PBKDF2-HMAC-SHA256，26 万轮，随机盐，常量时间比较
- token：HS256 的紧凑 JWT（三段式），带 exp，签名密钥来自环境变量或 data/secret.key
生产环境如果要更强的抗 GPU 能力，把 hash_password 换成 argon2-cffi 即可，
verify_password 会按存储前缀自动兼容旧口令。
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time

from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from . import cache, config, models
from .db import get_db

_PBKDF2_ROUNDS = 260_000
_ALGO = "pbkdf2_sha256"


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, _PBKDF2_ROUNDS)
    return f"{_ALGO}${_PBKDF2_ROUNDS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, rounds, salt_hex, digest_hex = stored.split("$")
    except (ValueError, AttributeError):
        return False
    if algo != _ALGO:
        return False
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), bytes.fromhex(salt_hex), int(rounds)
    )
    return hmac.compare_digest(digest.hex(), digest_hex)


def _secret_key() -> bytes:
    if config.SECRET_KEY:
        return config.SECRET_KEY.encode()
    if config.SECRET_FILE.exists():
        return config.SECRET_FILE.read_bytes()
    key = secrets.token_bytes(32)
    config.SECRET_FILE.parent.mkdir(parents=True, exist_ok=True)
    config.SECRET_FILE.write_bytes(key)
    try:
        os.chmod(config.SECRET_FILE, 0o600)
    except OSError:
        pass
    return key


def _b64encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def _b64decode(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def create_token(user_id: int, token_version: int = 0) -> str:
    now = int(time.time())
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "sub": str(user_id),
        # jti 用于 Redis 令牌存储：开启后登出即可让 token 立即失效
        "jti": secrets.token_hex(16),
        # ver 与 users.token_version 对应，改密自增后旧 token 立即失效
        "ver": token_version,
        "iat": now,
        "exp": now + config.TOKEN_TTL_HOURS * 3600,
    }
    seg_header = _b64encode(json.dumps(header, separators=(",", ":")).encode())
    seg_payload = _b64encode(json.dumps(payload, separators=(",", ":")).encode())
    signing_input = f"{seg_header}.{seg_payload}".encode()
    signature = hmac.new(_secret_key(), signing_input, hashlib.sha256).digest()
    return f"{seg_header}.{seg_payload}.{_b64encode(signature)}"


def decode_token(token: str) -> dict | None:
    """校验签名与过期时间，返回 payload（含 sub / jti）；失败返回 None。"""
    parts = token.split(".")
    if len(parts) != 3:
        return None
    seg_header, seg_payload, seg_signature = parts
    signing_input = f"{seg_header}.{seg_payload}".encode()
    expected = hmac.new(_secret_key(), signing_input, hashlib.sha256).digest()
    try:
        if not hmac.compare_digest(expected, _b64decode(seg_signature)):
            return None
        payload = json.loads(_b64decode(seg_payload))
    except (ValueError, json.JSONDecodeError):
        return None
    if int(payload.get("exp", 0)) < int(time.time()):
        return None
    return payload


def get_current_user(
    authorization: str = Header(default=""),
    db: Session = Depends(get_db),
) -> models.User:
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="缺少 Bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    claims = decode_token(authorization[7:].strip())
    if claims is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="token 无效或已过期"
        )
    try:
        user_id = int(claims["sub"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="token 无效或已过期"
        )
    if cache.enabled() and not cache.session_valid(claims.get("jti", "")):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="登录状态已失效，请重新登录"
        )
    user = db.get(models.User, user_id)
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="用户不存在")
    try:
        token_version = int(claims.get("ver", -1))
    except (TypeError, ValueError):
        token_version = -1
    if token_version != user.token_version:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="登录状态已失效，请重新登录"
        )
    return user


def get_admin_user(user: models.User = Depends(get_current_user)) -> models.User:
    """管理员专用操作（如数据库转换）的依赖：非管理员一律 403。"""
    if not user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="只有管理员可以执行该操作"
        )
    return user