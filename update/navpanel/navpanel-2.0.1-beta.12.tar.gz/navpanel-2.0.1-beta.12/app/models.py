"""数据模型：用户 → 分组 → 卡片，全部按 user_id 做账号隔离。"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, ForeignKey, Index, Integer, String, Text, text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    # 改密时自增，旧 token 里的 ver 不匹配即失效（无需 Redis 也能吊销）
    token_version: Mapped[int] = mapped_column(
        Integer, default=0, server_default=text("0")
    )
    # 是否允许未登录访客只读查看自己的面板（默认允许，可在面板设置里关闭）
    allow_guest: Mapped[bool] = mapped_column(
        Boolean, default=True, server_default=text("true")
    )
    # 是否在内容区上方显示搜索框（默认显示，可在面板设置里关闭）
    show_search: Mapped[bool] = mapped_column(
        Boolean, default=True, server_default=text("true")
    )
    # 是否隐藏顶部标题栏（隐藏后右上角留一个入口按钮，点击临时展开）
    hide_topbar: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default=text("false")
    )
    # 卡片新增/编辑弹窗的展示形态：modal（居中弹窗）/ drawer（右侧抽屉）
    card_popup_style: Mapped[str] = mapped_column(
        String(16), default="modal", server_default=text("'modal'")
    )
    # 卡片布局：center（图标居中）/ horizontal（图标在左，右侧上标题下描述）/ text（纯文字，只显示标题）
    card_layout: Mapped[str] = mapped_column(
        String(16), default="center", server_default=text("'center'")
    )
    # 每行卡片数：0 = 自动（按卡片最小宽度铺满），2~6 = 固定列数
    card_columns: Mapped[int] = mapped_column(
        Integer, default=0, server_default=text("0")
    )
    # 整页背景图：空串表示无背景；本地上传为 /backgrounds/xxx，也可填外链地址
    background_image: Mapped[str] = mapped_column(
        String(500), default="", server_default=text("''")
    )
    # 背景图不透明度 0~100：0 完全透明，100 完全显示
    background_opacity: Mapped[int] = mapped_column(
        Integer, default=100, server_default=text("100")
    )
    # 是否显示整页背景图：关闭后保留已配置的图片，只是不渲染
    background_enabled: Mapped[bool] = mapped_column(
        Boolean, default=True, server_default=text("true")
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    groups: Mapped[list["Group"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", passive_deletes=True
    )


class Group(Base):
    __tablename__ = "groups"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    title: Mapped[str] = mapped_column(String(120))
    sort: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    user: Mapped[User] = relationship(back_populates="groups")
    items: Mapped[list["Item"]] = relationship(
        back_populates="group", cascade="all, delete-orphan", passive_deletes=True
    )


class IconAsset(Base):
    """图标库条目。图标文件本身仍在 ICON_DIR，这里只存展示用的名称与分类。"""

    __tablename__ = "icon_assets"

    id: Mapped[int] = mapped_column(primary_key=True)
    filename: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120), default="")
    category: Mapped[str] = mapped_column(String(60), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Item(Base):
    __tablename__ = "items"
    # 面板固定按 (账号, 分组, 排序) 查询，复合索引避免全表扫描后再排序
    __table_args__ = (Index("ix_items_user_group_sort", "user_id", "group_id", "sort"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    group_id: Mapped[int | None] = mapped_column(
        ForeignKey("groups.id", ondelete="CASCADE"), index=True, nullable=True
    )
    title: Mapped[str] = mapped_column(String(120))
    url: Mapped[str] = mapped_column(Text)
    lan_url: Mapped[str] = mapped_column(Text, default="")
    description: Mapped[str] = mapped_column(String(255), default="")
    icon: Mapped[str] = mapped_column(String(255), default="")
    open_method: Mapped[str] = mapped_column(String(16), default="new")  # new / self / iframe
    # 卡片图标是否显示边框
    icon_bordered: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default=text("false")
    )
    # 是否必须登录才能查看（勾选后访客面板里不出现这张卡片）
    login_required: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default=text("false")
    )
    sort: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    group: Mapped[Group | None] = relationship(back_populates="items")


class SiteSetting(Base):
    """站点级设置：固定单行（id=1），标题与页脚全站共用，与账号无关。"""

    __tablename__ = "site_settings"

    id: Mapped[int] = mapped_column(primary_key=True)
    # 浏览器标签标题，同时用于登录页大标题与顶栏品牌文字；空串表示不显示
    site_title: Mapped[str] = mapped_column(
        String(64), default="", server_default=text("''")
    )
    # 页脚版权信息：空串表示不显示；支持 {year} 占位符，渲染时替换为当前年份
    footer_text: Mapped[str] = mapped_column(
        String(500), default="", server_default=text("''")
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow
    )