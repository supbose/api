"""请求/响应模型（Pydantic v2）。"""

from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict, Field, field_validator

OPEN_METHODS = {"new", "self", "iframe"}
CARD_POPUP_STYLES = {"modal", "drawer"}
CARD_LAYOUTS = {"center", "horizontal", "text"}
CARD_COLUMNS = {0, 2, 3, 4, 5, 6}  # 0 = 自动
# 本地上传的背景图：/backgrounds/<sha256 前 24 位>.<位图后缀>
LOCAL_BACKGROUND_RE = re.compile(r"^/backgrounds/[0-9a-f]{24}\.(?:png|jpg|gif|webp|bmp|ico)$")


def _clean_url(value: str) -> str:
    value = (value or "").strip()
    if value.startswith(("http://", "https://", "/")):
        return value
    if not value:
        return ""
    return f"https://{value}"


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=128)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    is_admin: bool
    show_search: bool = True
    hide_topbar: bool = False
    card_popup_style: str = "modal"
    card_layout: str = "center"
    card_columns: int = 0
    background_image: str = ""
    background_opacity: int = 100
    background_enabled: bool = True


class LoginOut(BaseModel):
    token: str
    user: UserOut


class PasswordChangeIn(BaseModel):
    old_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=8, max_length=128)


class GroupIn(BaseModel):
    title: str = Field(min_length=1, max_length=60)


class GroupOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    sort: int


class ItemIn(BaseModel):
    title: str = Field(min_length=1, max_length=60)
    url: str = Field(min_length=1, max_length=2048)
    lan_url: str = Field(default="", max_length=2048)
    description: str = Field(default="", max_length=200)
    icon: str = Field(default="", max_length=255)
    open_method: str = Field(default="new")
    group_id: int | None = None
    login_required: bool = False
    icon_bordered: bool = False

    @field_validator("url", "lan_url")
    @classmethod
    def normalize_url(cls, value: str) -> str:
        return _clean_url(value)

    @field_validator("open_method")
    @classmethod
    def validate_open_method(cls, value: str) -> str:
        if value not in OPEN_METHODS:
            raise ValueError(f"open_method 只能是 {sorted(OPEN_METHODS)} 之一")
        return value


class ItemUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=60)
    url: str | None = Field(default=None, min_length=1, max_length=2048)
    lan_url: str | None = Field(default=None, max_length=2048)
    description: str | None = Field(default=None, max_length=200)
    icon: str | None = Field(default=None, max_length=255)
    open_method: str | None = None
    group_id: int | None = None
    login_required: bool | None = None
    icon_bordered: bool | None = None

    @field_validator("url", "lan_url")
    @classmethod
    def normalize_url(cls, value: str | None) -> str | None:
        return value if value is None else _clean_url(value)

    @field_validator("open_method")
    @classmethod
    def validate_open_method(cls, value: str | None) -> str | None:
        if value is None:
            return value
        if value not in OPEN_METHODS:
            raise ValueError(f"open_method 只能是 {sorted(OPEN_METHODS)} 之一")
        return value


class ItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    group_id: int | None
    title: str
    url: str
    lan_url: str
    description: str
    icon: str
    open_method: str
    login_required: bool
    icon_bordered: bool
    sort: int


class ReorderIn(BaseModel):
    ids: list[int] = Field(min_length=1, max_length=500)


class IconFetchIn(BaseModel):
    url: str = Field(min_length=1, max_length=2048)


class IconCandidate(BaseModel):
    icon: str
    source: str


class IconFetchOut(BaseModel):
    icons: list[IconCandidate]


class IconAutoFillOut(BaseModel):
    total: int              # 卡片总数
    local: int              # 已有本地图标
    remote: int             # 外链图标
    empty: int              # 没有图标
    no_url: int             # 没有地址，无法抓取
    processed: int          # 本批尝试抓取
    filled: int             # 本批成功
    failed: int             # 本批失败
    failed_ids: list[int]   # 本批失败的卡片 id，供下一批排除
    remaining: int          # 剩余待抓取
    done: bool              # 是否已全部处理


class IconAssetOut(BaseModel):
    id: int
    name: str
    category: str
    icon: str


class IconLibraryOut(BaseModel):
    items: list[IconAssetOut]


class IconDeleteIn(BaseModel):
    ids: list[int] = Field(min_length=1, max_length=200)


class IconDeleteOut(BaseModel):
    deleted: int


class PanelOut(BaseModel):
    groups: list[dict]
    items: list[ItemOut]


class SiteSettingsOut(BaseModel):
    """站点级信息：标题与页脚，登录页和访客视图都要用，因此走公开接口。"""

    title: str
    # 已把 {year} 替换成当前年份，前端直接渲染即可
    footer: str
    # 未替换的原始文本：设置面板回填用，避免把年份固化进配置
    footer_template: str
    year: int


class SiteSettingsUpdate(BaseModel):
    """只传要改的字段；标题与页脚都允许留空，留空表示不显示。

    footer 存原始文本（允许 HTML），渲染前由 site.sanitize_footer 按白名单清洗。
    """

    title: str | None = Field(default=None, max_length=64)
    footer: str | None = Field(default=None, max_length=500)

    @field_validator("title")
    @classmethod
    def strip_title(cls, value: str | None) -> str | None:
        # 允许空串：清空后页面不再显示标题，而不是回退默认名
        return value.strip() if value is not None else value


class SettingsOut(BaseModel):
    """账号设置。public_mode 是服务端环境变量访客总开关，为 False 时 allow_guest 无效。"""

    allow_guest: bool
    show_search: bool
    hide_topbar: bool
    card_popup_style: str
    card_layout: str
    card_columns: int
    background_image: str
    background_opacity: int
    background_enabled: bool
    public_mode: bool


class SettingsUpdate(BaseModel):
    """只传要改的字段，未传的保持不变。"""

    allow_guest: bool | None = None
    show_search: bool | None = None
    hide_topbar: bool | None = None
    card_popup_style: str | None = None
    card_layout: str | None = None
    card_columns: int | None = None
    background_image: str | None = Field(default=None, max_length=500)
    background_opacity: int | None = Field(default=None, ge=0, le=100)
    background_enabled: bool | None = None

    @field_validator("background_image")
    @classmethod
    def validate_background_image(cls, value: str | None) -> str | None:
        if value is None:
            return value
        value = value.strip()
        if not value:
            return ""
        if value.startswith(("http://", "https://")) or LOCAL_BACKGROUND_RE.match(value):
            return value
        raise ValueError("background_image 只能是 http(s) 图片链接或已上传的本地背景图")

    @field_validator("card_popup_style")
    @classmethod
    def validate_card_popup_style(cls, value: str | None) -> str | None:
        if value is None:
            return value
        if value not in CARD_POPUP_STYLES:
            raise ValueError(f"card_popup_style 只能是 {sorted(CARD_POPUP_STYLES)} 之一")
        return value

    @field_validator("card_layout")
    @classmethod
    def validate_card_layout(cls, value: str | None) -> str | None:
        if value is None:
            return value
        if value not in CARD_LAYOUTS:
            raise ValueError(f"card_layout 只能是 {sorted(CARD_LAYOUTS)} 之一")
        return value

    @field_validator("card_columns")
    @classmethod
    def validate_card_columns(cls, value: int | None) -> int | None:
        if value is None:
            return value
        if value not in CARD_COLUMNS:
            raise ValueError(f"card_columns 只能是 {sorted(CARD_COLUMNS)} 之一（0 表示自动）")
        return value


class BackgroundUploadOut(BaseModel):
    """上传成功的本地背景图地址，保存设置时原样回传 background_image。"""

    image: str


DB_DIALECTS = {"sqlite", "mysql", "postgresql"}
# 完整连接串只接受这些协议，避免把任意驱动/任意 URL 交给 SQLAlchemy
DB_URL_SCHEMES = {
    "sqlite",
    "sqlite+pysqlite",
    "mysql",
    "mysql+pymysql",
    "postgresql",
    "postgresql+psycopg",
}


class DatabaseTargetIn(BaseModel):
    """数据库转换的目标库：dialect + 结构化参数，或高级模式直接给连接串。"""

    dialect: str = Field(default="sqlite")
    url: str | None = Field(default=None, max_length=1000)
    sqlite_path: str | None = Field(default=None, max_length=500)
    host: str | None = Field(default=None, max_length=255)
    port: int | None = Field(default=None, ge=1, le=65535)
    username: str | None = Field(default=None, max_length=128)
    password: str | None = Field(default=None, max_length=256)
    database: str | None = Field(default=None, max_length=128)
    charset: str = Field(default="utf8mb4", max_length=32)

    @field_validator("dialect")
    @classmethod
    def validate_dialect(cls, value: str) -> str:
        value = (value or "").strip().lower()
        if value not in DB_DIALECTS:
            raise ValueError(f"dialect 只能是 {sorted(DB_DIALECTS)} 之一")
        return value

    @field_validator("url")
    @classmethod
    def validate_url(cls, value: str | None) -> str | None:
        if value is None:
            return value
        value = value.strip()
        if not value:
            return ""
        scheme = value.split("://", 1)[0].lower() if "://" in value else ""
        if scheme not in DB_URL_SCHEMES:
            raise ValueError(f"连接串协议只能是 {sorted(DB_URL_SCHEMES)} 之一")
        return value


class DatabasePreviewIn(DatabaseTargetIn):
    pass


class DatabaseTransferIn(DatabaseTargetIn):
    # 高影响操作：confirm 必须显式给 true；目标库已有同名表时还要 overwrite
    confirm: bool = False
    overwrite: bool = False
    # 转换成功后把目标连接串写进 .env，重启后生效（默认不改动运行配置）
    update_env: bool = False


class DatabaseInfoOut(BaseModel):
    current: dict
    supported: list[dict]
    export_dir: str
    exports: list[dict]


class DatabasePreviewOut(BaseModel):
    source: dict
    target: dict
    tables: list[dict]
    existing_tables: list[dict]
    will_overwrite: bool
    warnings: list[str]
    same_database: bool = False


class DatabaseTransferOut(BaseModel):
    ok: bool
    source: dict
    target: dict
    tables: list[dict]
    total_rows: int
    duration_ms: int
    env_written: bool
    env_line: str
    restart_required: bool
    file: dict | None = None