"""数据库转换：把当前库的全部业务数据复制到另一个 SQLite / MySQL / PostgreSQL。

只处理本应用 ORM 元数据里的表（users / groups / items / icon_assets），
目标是换数据库而不是做通用 ETL：目标库里的其他表不会被读取或删除。

转换完成后本进程仍然连着旧库——切换数据库要改 NAVPANEL_DATABASE_URL 并重启，
所以这里额外提供 update_env（写 .env 并留备份）让用户自己决定要不要切。
"""

from __future__ import annotations

import logging
import os
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

from sqlalchemy import create_engine, func, inspect, select, text
from sqlalchemy.engine import Engine, make_url

from . import config, schemas
from . import models  # noqa: F401  确保 Base.metadata 已注册全部业务表
from .db import Base, engine as source_engine

logger = logging.getLogger(__name__)

# 支持的转换目标：dialect -> (展示名, 驱动模块, 安装提示)
DIALECTS: dict[str, dict[str, str]] = {
    "sqlite": {
        "label": "SQLite",
        "driver": "",
        "hint": "单文件数据库，无需额外驱动，适合备份与单机部署",
        "default_port": "",
    },
    "mysql": {
        "label": "MySQL / MariaDB",
        "driver": "pymysql",
        "hint": "需要安装驱动：pip install pymysql",
        "default_port": "3306",
    },
    "postgresql": {
        "label": "PostgreSQL",
        "driver": "psycopg",
        "hint": "需要安装驱动：pip install \"psycopg[binary]\"",
        "default_port": "5432",
    },
}

# 允许的 URL scheme（已带驱动的写法也放行）
ALLOWED_SCHEMES = {
    "sqlite",
    "sqlite+pysqlite",
    "mysql",
    "mysql+pymysql",
    "postgresql",
    "postgresql+psycopg",
}

SQLITE_SUFFIXES = {".db", ".sqlite", ".sqlite3", ".db3"}
BATCH_SIZE = 500


class TransferError(Exception):
    """转换过程中的可预期错误，由接口层转成 4xx 并原样展示给用户。"""

    def __init__(self, message: str, status_code: int = 400) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


# --------------------------------------------------------------------------
# 展示与校验
# --------------------------------------------------------------------------


def _driver_installed(module: str) -> bool:
    if not module:
        return True
    try:
        __import__(module)
    except Exception:  # noqa: BLE001 - 导入失败的原因不影响结论
        return False
    return True


def driver_status() -> list[dict]:
    """每个目标库是否就绪：前端据此提示先装驱动，而不是等转换时报错。"""
    result = []
    for dialect, meta in DIALECTS.items():
        installed = _driver_installed(meta["driver"])
        result.append(
            {
                "dialect": dialect,
                "label": meta["label"],
                "driver": meta["driver"],
                "driver_installed": installed,
                "hint": meta["hint"] if installed else f"缺少驱动，{meta['hint']}",
                "default_port": meta["default_port"],
            }
        )
    return result


def describe_url(url_text: str) -> dict:
    """把连接串拆成可展示的字段，密码一律不返回。"""
    try:
        url = make_url(url_text)
    except Exception:  # noqa: BLE001 - 非法 URL 只影响展示
        return {"dialect": "", "label": "未知", "host": "", "port": "", "database": "", "masked": ""}
    dialect = url.get_backend_name()
    database = url.database or ""
    if dialect == "sqlite":
        database = str(Path(database).name) if database and database != ":memory:" else (database or "")
    return {
        "dialect": dialect,
        "label": DIALECTS.get(dialect, {}).get("label", dialect),
        "host": url.host or "",
        "port": url.port or "",
        "database": database,
        "masked": url.render_as_string(hide_password=True),
    }


def _same_database(left: str, right: str) -> bool:
    """判断两个连接串是否指向同一个库（SQLite 按解析后的绝对路径比较）。"""
    try:
        a, b = make_url(left), make_url(right)
    except Exception:  # noqa: BLE001
        return left == right
    if a.get_backend_name() != b.get_backend_name():
        return False
    if a.get_backend_name() == "sqlite":
        def _path(url) -> str:
            raw = url.database or ""
            if raw in ("", ":memory:"):
                return raw
            return str(Path(raw).expanduser().resolve())

        return _path(a) == _path(b)
    return (
        (a.host or "").lower() == (b.host or "").lower()
        and (a.port or 0) == (b.port or 0)
        and (a.database or "") == (b.database or "")
    )


def resolve_sqlite_path(raw: str | None) -> Path:
    """目标 SQLite 文件只允许落在数据目录内，避免写出任意路径。"""
    data_root = config.DATA_DIR.resolve()
    if raw and raw.strip():
        candidate = Path(raw.strip()).expanduser()
        if not candidate.is_absolute():
            candidate = data_root / candidate
        path = candidate.resolve()
        if not path.is_relative_to(data_root):
            raise TransferError("SQLite 目标文件必须位于数据目录内（默认 data/exports）")
        if path == data_root or path.is_dir():
            raise TransferError("SQLite 目标路径必须是一个文件路径")
        if path.suffix.lower() not in SQLITE_SUFFIXES:
            path = path.with_name(path.name + ".db")
        return path
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return (config.EXPORT_DIR / f"navpanel-{stamp}.db").resolve()


def build_target_url(target: schemas.DatabaseTargetIn) -> tuple[str, Path | None]:
    """把表单参数拼成 SQLAlchemy 连接串；SQLite 返回实际文件路径。"""
    dialect = target.dialect
    if dialect not in DIALECTS:
        raise TransferError(f"不支持的目标类型 {dialect}，可选 {sorted(DIALECTS)}")

    if target.url and target.url.strip():
        url_text = target.url.strip()
        try:
            url = make_url(url_text)
        except Exception:  # noqa: BLE001
            raise TransferError("连接串格式不正确，示例：mysql+pymysql://user:pass@127.0.0.1:3306/navpanel")
        scheme = url.drivername.lower()
        if scheme not in ALLOWED_SCHEMES:
            raise TransferError(f"不支持的连接串协议 {scheme}，可选 {sorted(ALLOWED_SCHEMES)}")
        if url.get_backend_name() != dialect:
            raise TransferError(f"连接串协议与所选目标类型（{dialect}）不一致")
        if dialect == "sqlite":
            path = resolve_sqlite_path(url.database or None)
            return f"sqlite:///{path.as_posix()}", path
        return url_text, None

    if dialect == "sqlite":
        path = resolve_sqlite_path(target.sqlite_path)
        return f"sqlite:///{path.as_posix()}", path

    if not _driver_installed(DIALECTS[dialect]["driver"]):
        meta = DIALECTS[dialect]
        raise TransferError(f"目标数据库驱动未安装：{meta['hint']}")

    host = (target.host or "").strip() or "127.0.0.1"
    username = (target.username or "").strip()
    database = (target.database or "").strip()
    if not database:
        raise TransferError("请填写目标数据库名")
    if not username:
        raise TransferError("请填写目标数据库用户名")

    port = target.port or int(DIALECTS[dialect]["default_port"])
    auth = quote_plus(username)
    if target.password:
        auth += ":" + quote_plus(target.password)
    if dialect == "mysql":
        charset = (target.charset or "utf8mb4").strip() or "utf8mb4"
        return (
            f"mysql+pymysql://{auth}@{host}:{port}/{database}?charset={charset}",
            None,
        )
    return f"postgresql+psycopg://{auth}@{host}:{port}/{database}", None


def _target_engine(url_text: str) -> Engine:
    is_sqlite = url_text.startswith("sqlite")
    kwargs = {
        "connect_args": {"check_same_thread": False} if is_sqlite else {},
        "pool_pre_ping": not is_sqlite,
        "future": True,
    }
    try:
        return create_engine(url_text, **kwargs)
    except Exception as exc:  # noqa: BLE001
        raise TransferError(f"无法创建目标库连接：{exc}")


def _count_rows(engine: Engine, table_name: str) -> int:
    table = Base.metadata.tables[table_name]
    with engine.connect() as conn:
        return int(conn.execute(select(func.count()).select_from(table)).scalar_one())


def _target_tables(engine: Engine) -> list[str]:
    return [name for name in inspect(engine).get_table_names()]


# --------------------------------------------------------------------------
# 预览
# --------------------------------------------------------------------------


def _source_snapshot() -> dict:
    counts = {}
    total = 0
    for table in Base.metadata.sorted_tables:
        rows = _count_rows(source_engine, table.name)
        counts[table.name] = rows
        total += rows
    return {"url": describe_url(config.DATABASE_URL), "tables": counts, "total": total}


def preview(target: schemas.DatabaseTargetIn) -> dict:
    """只读检测：当前库行数、目标库已有表、将要覆盖的内容。"""
    target_url, sqlite_path = build_target_url(target)
    if _same_database(target_url, config.DATABASE_URL):
        raise TransferError("目标库与当前数据库是同一个库，无需转换")

    source = _source_snapshot()
    target_desc = describe_url(target_url)
    ours = [table.name for table in Base.metadata.sorted_tables]

    existing = []
    existing_names: list[str] = []
    # SQLite 目标文件不存在时视为空库：不建连接，避免检测动作就留下一个空文件
    if sqlite_path is None or sqlite_path.exists():
        target_engine = _target_engine(target_url)
        try:
            existing_names = _target_tables(target_engine)
            for name in existing_names:
                if name in ours:
                    try:
                        rows = _count_rows(target_engine, name)
                    except Exception:  # noqa: BLE001
                        rows = 0
                    existing.append({"name": name, "rows": rows, "ours": True})
                else:
                    existing.append({"name": name, "rows": None, "ours": False})
        except Exception as exc:  # noqa: BLE001
            raise TransferError(f"无法连接目标库：{exc}")
        finally:
            target_engine.dispose()

    will_overwrite = any(row["ours"] for row in existing)
    warnings = []
    if will_overwrite:
        warnings.append("目标库已存在本应用的表，继续转换会删除并重建这些表")
    extra = [row["name"] for row in existing if not row["ours"]]
    if extra:
        warnings.append("目标库还有其他表（不读取也不删除）：" + "、".join(extra))
    if target_desc["dialect"] == "sqlite":
        warnings.append("SQLite 产物会放在数据目录内，转换完成后可直接下载")

    return {
        "source": source,
        "target": target_desc,
        "tables": [
            {"name": name, "source_rows": source["tables"][name]}
            for name in ours
        ],
        "existing_tables": existing,
        "will_overwrite": will_overwrite,
        "warnings": warnings,
        "same_database": False,
    }


# --------------------------------------------------------------------------
# 转换
# --------------------------------------------------------------------------


def _reset_postgres_sequences(conn) -> None:
    """按显式 id 插入后，PostgreSQL 的自增序列要追到 max(id)，否则后续插入冲突。"""
    for table in Base.metadata.sorted_tables:
        if "id" not in table.columns:
            continue
        conn.execute(
            text(
                f'SELECT setval(pg_get_serial_sequence(:t, \'id\'), '
                f'COALESCE((SELECT MAX(id) FROM "{table.name}"), 1), '
                f'(SELECT MAX(id) IS NOT NULL FROM "{table.name}"))'
            ),
            {"t": table.name},
        )


def transfer(
    target: schemas.DatabaseTargetIn,
    *,
    overwrite: bool = False,
    confirm: bool = False,
    update_env: bool = False,
) -> dict:
    """执行转换。调用方负责鉴权；这里只做数据层校验。"""
    if not confirm:
        raise TransferError("转换会写入目标数据库，需要显式确认后再执行")
    target_url, sqlite_path = build_target_url(target)
    if _same_database(target_url, config.DATABASE_URL):
        raise TransferError("目标库与当前数据库是同一个库，无需转换")

    started = time.perf_counter()
    created_file = bool(sqlite_path and not sqlite_path.exists())
    if sqlite_path is not None:
        sqlite_path.parent.mkdir(parents=True, exist_ok=True)

    target_engine = _target_engine(target_url)
    ours = [table.name for table in Base.metadata.sorted_tables]

    try:
        existing = [name for name in _target_tables(target_engine) if name in ours]
        if existing and not overwrite:
            raise TransferError(
                "目标库已存在本应用的表（" + "、".join(existing) + "），需确认覆盖后才能继续",
                status_code=409,
            )
        try:
            if existing:
                Base.metadata.drop_all(target_engine)
            Base.metadata.create_all(target_engine)
        except Exception as exc:  # noqa: BLE001
            raise TransferError(f"目标库建表失败：{exc}")

        report_tables: list[dict] = []
        with source_engine.connect() as src:
            with target_engine.begin() as dst:
                for table in Base.metadata.sorted_tables:
                    copied = 0
                    result = src.execute(select(table))
                    while True:
                        batch = result.fetchmany(BATCH_SIZE)
                        if not batch:
                            break
                        rows = [dict(row._mapping) for row in batch]
                        dst.execute(table.insert(), rows)
                        copied += len(rows)
                    report_tables.append({"name": table.name, "copied": copied})
                if target_engine.dialect.name == "postgresql":
                    _reset_postgres_sequences(dst)

        for item in report_tables:
            expected = _count_rows(source_engine, item["name"])
            actual = _count_rows(target_engine, item["name"])
            item["source_rows"] = expected
            item["target_rows"] = actual
            item["verified"] = expected == actual
        broken = [item["name"] for item in report_tables if not item["verified"]]
        if broken:
            raise TransferError(
                "数据校验失败：以下表的行数不一致 " + "、".join(broken), status_code=500
            )
    except TransferError:
        if created_file and sqlite_path is not None:
            sqlite_path.unlink(missing_ok=True)
        raise
    except Exception as exc:  # noqa: BLE001
        if created_file and sqlite_path is not None:
            sqlite_path.unlink(missing_ok=True)
        logger.exception("数据库转换失败")
        raise TransferError(f"数据库转换失败：{exc}", status_code=500)
    finally:
        target_engine.dispose()

    total_rows = sum(item["copied"] for item in report_tables)
    env_line = f"NAVPANEL_DATABASE_URL={target_url}"
    env_written = False
    if update_env:
        env_written = write_env(target_url)

    file_info = None
    if sqlite_path is not None:
        size = sqlite_path.stat().st_size if sqlite_path.exists() else 0
        file_info = {
            "name": sqlite_path.name,
            "size": size,
            "path": str(sqlite_path.relative_to(config.DATA_DIR.resolve())),
            "download": f"/api/database/download?name={quote_plus(sqlite_path.name)}",
        }

    return {
        "ok": True,
        "source": describe_url(config.DATABASE_URL),
        "target": describe_url(target_url),
        "tables": report_tables,
        "total_rows": total_rows,
        "duration_ms": int((time.perf_counter() - started) * 1000),
        "env_written": env_written,
        "env_line": env_line,
        "restart_required": True,
        "file": file_info,
    }


# --------------------------------------------------------------------------
# 切换与产物
# --------------------------------------------------------------------------


def write_env(url_text: str) -> bool:
    """把目标连接串写进 .env（保留其他行，旧文件备份为 .env.bak），重启后生效。"""
    path = config.BASE_DIR / ".env"
    try:
        lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
        if path.exists():
            (config.BASE_DIR / ".env.bak").write_text(
                "\n".join(lines) + "\n", encoding="utf-8"
            )
        replaced = False
        for index, line in enumerate(lines):
            if line.strip().startswith("NAVPANEL_DATABASE_URL="):
                lines[index] = f"NAVPANEL_DATABASE_URL={url_text}"
                replaced = True
                break
        if not replaced:
            if lines and lines[-1].strip():
                lines.append("")
            lines.append(f"NAVPANEL_DATABASE_URL={url_text}")
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return True
    except OSError as exc:
        logger.warning("写入 .env 失败：%s", exc)
        return False


def list_exports() -> list[dict]:
    """数据目录里的 SQLite 产物，供设置面板直接下载。"""
    directory = config.EXPORT_DIR
    if not directory.is_dir():
        return []
    files = []
    for entry in sorted(directory.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True):
        stat = entry.stat()
        files.append(
            {
                "name": entry.name,
                "size": stat.st_size,
                "mtime": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                "download": f"/api/database/download?name={quote_plus(entry.name)}",
            }
        )
    return files


def resolve_export_file(name: str) -> Path:
    """下载接口用：只认导出目录里的文件名，挡掉路径穿越。"""
    if not name or "/" in name or "\\" in name or name in (".", ".."):
        raise TransferError("文件名不合法")
    path = (config.EXPORT_DIR / name).resolve()
    if not path.is_relative_to(config.EXPORT_DIR.resolve()) or not path.exists():
        raise TransferError("文件不存在", status_code=404)
    if path.suffix.lower() not in SQLITE_SUFFIXES:
        raise TransferError("只能下载 SQLite 数据文件")
    return path


def info() -> dict:
    snapshot = _source_snapshot()
    return {
        "current": snapshot,
        "supported": driver_status(),
        "export_dir": str(config.EXPORT_DIR),
        "exports": list_exports(),
    }


__all__ = [
    "ALLOWED_SCHEMES",
    "DIALECTS",
    "TransferError",
    "build_target_url",
    "describe_url",
    "driver_status",
    "info",
    "list_exports",
    "preview",
    "resolve_export_file",
    "resolve_sqlite_path",
    "transfer",
    "write_env",
]