"""登录与账号相关接口。"""

from __future__ import annotations

import secrets

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy.orm import Session

from .. import cache, config, login_guard, models, schemas
from ..db import get_db
from ..security import (
    create_token,
    decode_token,
    get_current_user,
    hash_password,
    verify_password,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])

# 用户不存在时也走一次同等开销的哈希校验，避免通过响应耗时枚举用户名
_DUMMY_HASH = hash_password(secrets.token_hex(16))


@router.post("/login", response_model=schemas.LoginOut)
def login(
    payload: schemas.LoginIn, request: Request, db: Session = Depends(get_db)
) -> schemas.LoginOut:
    ip = request.client.host if request.client else "unknown"
    if login_guard.blocked(ip):
        raise HTTPException(status_code=429, detail="登录失败次数过多，请 15 分钟后再试")
    user = db.query(models.User).filter_by(username=payload.username).first()
    stored = user.password_hash if user is not None else _DUMMY_HASH
    password_ok = verify_password(payload.password, stored)
    if user is None or not password_ok:
        login_guard.record_failure(ip)
        raise HTTPException(status_code=401, detail="用户名或密码不正确")
    login_guard.reset(ip)
    token = create_token(user.id, user.token_version)
    claims = decode_token(token) or {}
    cache.store_session(
        claims.get("jti", ""), user.id, config.TOKEN_TTL_HOURS * 3600
    )
    return schemas.LoginOut(token=token, user=schemas.UserOut.model_validate(user))


@router.post("/logout", status_code=204)
def logout(authorization: str = Header(default="")) -> None:
    """开启 Redis 时立即吊销当前 token；未开启时客户端清掉 token 即可。"""
    token = authorization[7:].strip() if authorization.lower().startswith("bearer ") else ""
    claims = decode_token(token) if token else None
    if claims:
        cache.drop_session(claims.get("jti", ""))


@router.get("/me", response_model=schemas.UserOut)
def me(user: models.User = Depends(get_current_user)) -> schemas.UserOut:
    return schemas.UserOut.model_validate(user)


@router.post("/password", status_code=204)
def change_password(
    payload: schemas.PasswordChangeIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> None:
    if not verify_password(payload.old_password, user.password_hash):
        raise HTTPException(status_code=400, detail="原密码不正确")
    user.password_hash = hash_password(payload.new_password)
    # 自增版本号让所有已签发的旧 token 立即失效（包括疑似泄露的）
    user.token_version += 1
    db.add(user)
    db.commit()