"""站点级设置的读写接口。

GET 公开：登录页与访客视图都要先拿到站点标题与页脚版权；
PATCH 仅管理员：站点信息全站生效，不允许普通账号改动。
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import models, schemas, site
from ..db import get_db
from ..security import get_admin_user

router = APIRouter(prefix="/api/site", tags=["site"])


@router.get("", response_model=schemas.SiteSettingsOut)
def read_site(db: Session = Depends(get_db)) -> schemas.SiteSettingsOut:
    return site.payload(db)


@router.patch("", response_model=schemas.SiteSettingsOut)
def update_site(
    payload: schemas.SiteSettingsUpdate,
    _admin: models.User = Depends(get_admin_user),
    db: Session = Depends(get_db),
) -> schemas.SiteSettingsOut:
    changes = payload.model_dump(exclude_unset=True, exclude_none=True)
    row = site.get_row(db)
    if "title" in changes:
        row.site_title = str(changes["title"]).strip()
    if "footer" in changes:
        row.footer_text = str(changes["footer"]).strip()
    if changes:
        db.add(row)
        db.commit()
        db.refresh(row)
    return site.payload(db)