"""数据库转换接口：管理当前库与目标库之间的数据搬迁。

全部接口都要求管理员身份——转换会写入（甚至覆盖）另一个数据库，属于高影响操作。
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import FileResponse

from .. import db_transfer, models, schemas
from ..security import get_admin_user

router = APIRouter(prefix="/api/database", tags=["database"])


def _to_http(exc: db_transfer.TransferError) -> HTTPException:
    return HTTPException(status_code=exc.status_code, detail=exc.message)


@router.get("", response_model=schemas.DatabaseInfoOut)
def database_info(
    _user: models.User = Depends(get_admin_user),
) -> schemas.DatabaseInfoOut:
    """当前数据库概况、支持的目标类型与驱动状态、已生成的 SQLite 产物。"""
    return schemas.DatabaseInfoOut(**db_transfer.info())


@router.post("/preview", response_model=schemas.DatabasePreviewOut)
def database_preview(
    payload: schemas.DatabasePreviewIn,
    _user: models.User = Depends(get_admin_user),
) -> schemas.DatabasePreviewOut:
    """只读检测：不改动目标库，只返回两侧行数与将要覆盖的表。"""
    try:
        return schemas.DatabasePreviewOut(**db_transfer.preview(payload))
    except db_transfer.TransferError as exc:
        raise _to_http(exc)


@router.post("/transfer", response_model=schemas.DatabaseTransferOut)
def database_transfer(
    payload: schemas.DatabaseTransferIn,
    _user: models.User = Depends(get_admin_user),
) -> schemas.DatabaseTransferOut:
    """把当前库的四张业务表复制到目标库；已有同名表时需 overwrite=true。"""
    try:
        return schemas.DatabaseTransferOut(
            **db_transfer.transfer(
                payload,
                overwrite=payload.overwrite,
                confirm=payload.confirm,
                update_env=payload.update_env,
            )
        )
    except db_transfer.TransferError as exc:
        raise _to_http(exc)


@router.get("/download")
def database_download(
    name: str = Query(min_length=1, max_length=255),
    _user: models.User = Depends(get_admin_user),
) -> FileResponse:
    """下载数据目录里导出的 SQLite 文件（只认导出目录内的文件名）。"""
    try:
        path = db_transfer.resolve_export_file(name)
    except db_transfer.TransferError as exc:
        raise _to_http(exc)
    return FileResponse(
        path,
        media_type="application/octet-stream",
        filename=path.name,
        status_code=status.HTTP_200_OK,
    )