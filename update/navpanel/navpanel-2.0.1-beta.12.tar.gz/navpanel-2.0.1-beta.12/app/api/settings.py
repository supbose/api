"""当前账号的偏好设置：访客查看开关、搜索框显示开关、卡片布局与整页背景图。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from .. import cache, config, icons, models, schemas
from ..db import get_db
from ..security import get_current_user

router = APIRouter(prefix="/api/settings", tags=["settings"])


def _payload(user: models.User) -> schemas.SettingsOut:
    return schemas.SettingsOut(
        allow_guest=user.allow_guest,
        show_search=user.show_search,
        hide_topbar=user.hide_topbar,
        card_popup_style=user.card_popup_style,
        card_layout=user.card_layout,
        card_columns=user.card_columns,
        background_image=user.background_image,
        background_opacity=user.background_opacity,
        background_enabled=bool(user.background_enabled),
        public_mode=config.PUBLIC_MODE,
    )


def _remove_background_file(value: str) -> None:
    """换图或清除背景时删掉旧的本地文件；外链地址不做处理。"""
    if not value.startswith("/backgrounds/"):
        return
    (config.BACKGROUND_DIR / value.rsplit("/", 1)[-1]).unlink(missing_ok=True)


@router.get("", response_model=schemas.SettingsOut)
def read_settings(user: models.User = Depends(get_current_user)) -> schemas.SettingsOut:
    return _payload(user)


@router.post("/background", response_model=schemas.BackgroundUploadOut)
def upload_background(
    file: UploadFile = File(...),
    _user: models.User = Depends(get_current_user),
) -> schemas.BackgroundUploadOut:
    """只把图片存到背景目录并返回地址，是否启用由保存设置时的 background_image 决定。"""
    content = file.file.read(config.BACKGROUND_MAX_BYTES + 1)
    if len(content) > config.BACKGROUND_MAX_BYTES:
        raise HTTPException(status_code=413, detail="背景图文件超过 8MB")
    return schemas.BackgroundUploadOut(image=icons.save_background(content))


@router.patch("", response_model=schemas.SettingsOut)
def update_settings(
    payload: schemas.SettingsUpdate,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.SettingsOut:
    changes = payload.model_dump(exclude_unset=True, exclude_none=True)
    if not changes:
        return _payload(user)

    if "allow_guest" in changes:
        user.allow_guest = bool(changes["allow_guest"])
    if "show_search" in changes:
        user.show_search = bool(changes["show_search"])
    if "hide_topbar" in changes:
        user.hide_topbar = bool(changes["hide_topbar"])
    if "card_popup_style" in changes:
        user.card_popup_style = str(changes["card_popup_style"])
    if "card_layout" in changes:
        user.card_layout = str(changes["card_layout"])
    if "card_columns" in changes:
        user.card_columns = int(changes["card_columns"])
    if "background_image" in changes:
        next_image = str(changes["background_image"])
        if next_image != user.background_image:
            _remove_background_file(user.background_image)
        user.background_image = next_image
    if "background_opacity" in changes:
        user.background_opacity = int(changes["background_opacity"])
    if "background_enabled" in changes:
        user.background_enabled = bool(changes["background_enabled"])

    db.add(user)
    db.commit()
    db.refresh(user)
    cache.invalidate_user(user.id)
    return _payload(user)
