"""图标抓取与图标库接口。"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlparse

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    UploadFile,
    status,
)
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .. import cache, config, icons, models, schemas
from ..db import get_db
from ..security import get_current_user

router = APIRouter(prefix="/api/icons", tags=["icons"])

AUTO_CATEGORY = "自动抓取"
CUSTOM_CATEGORY = "自定义"


@router.post("/fetch", response_model=schemas.IconFetchOut)
def fetch(
    payload: schemas.IconFetchIn,
    request: Request,
    db: Session = Depends(get_db),
    _user: models.User = Depends(get_current_user),
) -> schemas.IconFetchOut:
    ip = request.client.host if request.client else "unknown"
    if not cache.allow_icon_fetch(ip):
        raise HTTPException(status_code=429, detail="图标抓取过于频繁，请稍后再试")
    found = icons.fetch_icons(payload.url)
    _register_fetched(db, found)
    return schemas.IconFetchOut(
        icons=[schemas.IconCandidate(icon=icon, source=source) for icon, source in found]
    )


AUTO_FILL_WORKERS = 6
AUTO_FILL_BATCH = 12


@router.post("/auto-fill", response_model=schemas.IconAutoFillOut)
def auto_fill(
    limit: int = Query(AUTO_FILL_BATCH, ge=1, le=50),
    exclude: str = Query("", max_length=4000),
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.IconAutoFillOut:
    """分批为缺少本地图标的卡片抓取图标，供前端显示进度。

    已有本地图标（/icons/ 开头）跳过；没有地址的卡片计入 no_url，无法抓取。
    exclude 传本轮已失败的卡片 id（逗号分隔），避免它被反复重试。
    """
    excluded = {int(part) for part in exclude.split(",") if part.strip().isdigit()}
    items = db.query(models.Item).filter(models.Item.user_id == user.id).all()
    local = remote = empty = no_url = 0
    candidates: list[tuple[models.Item, str]] = []
    for item in items:
        if item.icon.startswith("/icons/"):
            local += 1
            continue
        if item.icon.strip():
            remote += 1
        else:
            empty += 1
        target = (item.url or "").strip() or (item.lan_url or "").strip()
        if not target:
            no_url += 1
            continue
        if item.id in excluded:
            continue
        candidates.append((item, target))

    batch = candidates[:limit]
    filled = 0
    failed_ids: list[int] = []
    found_icons: list[tuple[str, str]] = []
    if batch:

        def grab(pair: tuple[models.Item, str]) -> list[tuple[str, str]]:
            item, target = pair
            icon = item.icon.strip()
            # 已有外链图标先原样下载为本地副本；站点本身可能抓不到，但图标地址通常可用
            if icon.startswith(("http://", "https://")):
                try:
                    return [(icons.cache_icon(icon), icon)]
                except Exception:  # 外链失效再退回抓站点图标
                    pass
            try:
                return icons.fetch_icons(target)
            except Exception:  # 单个站点超时/无图标都不影响整批
                return []

        with ThreadPoolExecutor(max_workers=AUTO_FILL_WORKERS) as pool:
            results = list(pool.map(grab, batch))
        for (item, _), found in zip(batch, results):
            if not found:
                failed_ids.append(item.id)
                continue
            item.icon = found[0][0]
            db.add(item)
            found_icons.extend(found)
            filled += 1
        if filled:
            db.commit()
            _register_fetched(db, found_icons)
            cache.invalidate_user(user.id)

    remaining = len(candidates) - len(batch)
    return schemas.IconAutoFillOut(
        total=len(items),
        local=local,
        remote=remote,
        empty=empty,
        no_url=no_url,
        processed=len(batch),
        filled=filled,
        failed=len(failed_ids),
        failed_ids=failed_ids,
        remaining=remaining,
        done=remaining == 0,
    )


def sync_library(db: Session) -> None:
    """把 ICON_DIR 里还没登记的图标补进图标库（仅启动时调用一次）。

    名称优先取引用这张图的卡片标题（自动抓取的图标通常已被某张卡片用上），
    否则退回文件名前缀，保证每个缓存图标都能在图标库里被选到。
    """
    known = {row[0] for row in db.query(models.IconAsset.filename)}
    files = [path for path in config.ICON_DIR.iterdir() if path.is_file()]
    if not files:
        return
    referenced: dict[str, str] = {}
    rows = (
        db.query(models.Item.icon, models.Item.title)
        .filter(models.Item.icon != "")
        .order_by(models.Item.id)
    )
    for icon, title in rows:
        referenced.setdefault(icon, title)
    added = False
    for path in files:
        filename = f"/icons/{path.name}"
        if filename in known:
            continue
        db.add(
            models.IconAsset(
                filename=filename,
                name=referenced.get(filename) or path.stem[:12],
                category=AUTO_CATEGORY,
            )
        )
        added = True
    if added:
        try:
            db.commit()
        except IntegrityError:  # 并发请求同时补登记，保留先写入的那条即可
            db.rollback()


def _register_fetched(db: Session, found: list[tuple[str, str]]) -> None:
    """抓取到的图标立即登记，避免每次打开图标库都扫描整个缓存目录。"""
    if not found:
        return
    known = {row[0] for row in db.query(models.IconAsset.filename)}
    added = False
    for icon, source in found:
        if icon in known:
            continue
        name = urlparse(source).hostname or Path(icon).stem[:12]
        db.add(models.IconAsset(filename=icon, name=name[:120], category=AUTO_CATEGORY))
        known.add(icon)
        added = True
    if added:
        try:
            db.commit()
        except IntegrityError:  # 并发抓取同一图标，保留先写入的那条即可
            db.rollback()


@router.get("/library", response_model=schemas.IconLibraryOut)
def library(
    db: Session = Depends(get_db),
    _user: models.User = Depends(get_current_user),
) -> schemas.IconLibraryOut:
    rows = (
        db.query(models.IconAsset)
        .order_by(models.IconAsset.category, models.IconAsset.name, models.IconAsset.id)
        .all()
    )
    return schemas.IconLibraryOut(
        items=[_asset_out(row) for row in rows]
    )


def _asset_out(asset: models.IconAsset) -> schemas.IconAssetOut:
    return schemas.IconAssetOut(
        id=asset.id, name=asset.name, category=asset.category, icon=asset.filename
    )


def _remove_assets(db: Session, assets: list[models.IconAsset]) -> int:
    """删除图标库条目并移除对应的图标文件（卡片引用会自动回退为首字母）。"""
    for asset in assets:
        (config.ICON_DIR / Path(asset.filename).name).unlink(missing_ok=True)
        db.delete(asset)
    db.commit()
    return len(assets)


@router.post("/library", response_model=schemas.IconAssetOut)
def upload_icon(
    file: UploadFile = File(...),
    name: str = Form(""),
    category: str = Form(""),
    db: Session = Depends(get_db),
    _user: models.User = Depends(get_current_user),
) -> schemas.IconAssetOut:
    content = file.file.read(config.ICON_MAX_BYTES + 1)
    if len(content) > config.ICON_MAX_BYTES:
        raise HTTPException(status_code=413, detail="图标文件超过 512KB")
    ext = icons._detect_ext(content, (file.content_type or "").lower())
    if ext is None:
        raise HTTPException(
            status_code=415,
            detail="只支持位图格式（PNG/JPG/GIF/WebP/BMP/ICO），不支持 SVG",
        )
    # _store 会真正解码校验：仅伪造 Content-Type 的非图片字节在这里被拒
    filename = icons._store(content)
    asset = db.query(models.IconAsset).filter_by(filename=filename).first()
    clean_name = (name or "").strip()[:120] or Path(file.filename or "").stem[:120] or "上传图标"
    clean_category = (category or "").strip()[:60] or CUSTOM_CATEGORY
    if asset is None:
        asset = models.IconAsset(
            filename=filename, name=clean_name, category=clean_category
        )
        db.add(asset)
    else:  # 同一张图重复上传时更新名称与分类，不产生重复条目
        asset.name = clean_name
        asset.category = clean_category
    db.commit()
    db.refresh(asset)
    return _asset_out(asset)


@router.delete("/library/{asset_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_icon(
    asset_id: int,
    db: Session = Depends(get_db),
    _user: models.User = Depends(get_current_user),
) -> None:
    asset = db.get(models.IconAsset, asset_id)
    if asset is None:
        raise HTTPException(status_code=404, detail="图标不存在")
    _remove_assets(db, [asset])


@router.post("/library/delete", response_model=schemas.IconDeleteOut)
def delete_icons(
    payload: schemas.IconDeleteIn,
    db: Session = Depends(get_db),
    _user: models.User = Depends(get_current_user),
) -> schemas.IconDeleteOut:
    assets = db.query(models.IconAsset).filter(models.IconAsset.id.in_(payload.ids)).all()
    return schemas.IconDeleteOut(deleted=_remove_assets(db, assets))
