"""分组 CRUD 与排序。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import cache, models, schemas
from ..db import get_db
from ..security import get_current_user

router = APIRouter(prefix="/api/groups", tags=["groups"])


@router.get("", response_model=list[schemas.GroupOut])
def list_groups(
    user: models.User = Depends(get_current_user), db: Session = Depends(get_db)
) -> list[schemas.GroupOut]:
    rows = (
        db.query(models.Group)
        .filter_by(user_id=user.id)
        .order_by(models.Group.sort, models.Group.id)
        .all()
    )
    return [schemas.GroupOut.model_validate(row) for row in rows]


@router.post("", response_model=schemas.GroupOut, status_code=status.HTTP_201_CREATED)
def create_group(
    payload: schemas.GroupIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.GroupOut:
    next_sort = (
        db.query(func.coalesce(func.max(models.Group.sort), 0))
        .filter(models.Group.user_id == user.id)
        .scalar()
        or 0
    ) + 1
    group = models.Group(user_id=user.id, title=payload.title.strip(), sort=next_sort)
    db.add(group)
    db.commit()
    db.refresh(group)
    cache.invalidate_user(user.id)
    return schemas.GroupOut.model_validate(group)


def _get_owned(db: Session, user: models.User, group_id: int) -> models.Group:
    group = db.get(models.Group, group_id)
    if group is None or group.user_id != user.id:
        raise HTTPException(status_code=404, detail="分组不存在")
    return group


@router.patch("/{group_id}", response_model=schemas.GroupOut)
def rename_group(
    group_id: int,
    payload: schemas.GroupIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.GroupOut:
    group = _get_owned(db, user, group_id)
    group.title = payload.title.strip()
    db.add(group)
    db.commit()
    db.refresh(group)
    cache.invalidate_user(user.id)
    return schemas.GroupOut.model_validate(group)


@router.delete("/{group_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_group(
    group_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> None:
    group = _get_owned(db, user, group_id)
    db.delete(group)
    db.commit()
    cache.invalidate_user(user.id)


@router.post("/reorder", status_code=status.HTTP_204_NO_CONTENT)
def reorder_groups(
    payload: schemas.ReorderIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> None:
    rows = db.query(models.Group).filter(models.Group.user_id == user.id).all()
    owned = {row.id: row for row in rows}
    if set(payload.ids) - owned.keys():
        raise HTTPException(status_code=400, detail="包含不属于当前账号的分组")
    for index, group_id in enumerate(payload.ids):
        owned[group_id].sort = index
        db.add(owned[group_id])
    db.commit()
    cache.invalidate_user(user.id)