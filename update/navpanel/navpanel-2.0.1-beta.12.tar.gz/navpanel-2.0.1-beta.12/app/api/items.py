"""卡片（书签）CRUD 与排序。"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import cache, models, schemas
from ..db import get_db
from ..security import get_current_user

router = APIRouter(prefix="/api/items", tags=["items"])


@router.get("", response_model=list[schemas.ItemOut])
def list_items(
    group_id: int | None = None,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> list[schemas.ItemOut]:
    query = db.query(models.Item).filter(models.Item.user_id == user.id)
    if group_id is not None:
        query = query.filter(models.Item.group_id == group_id)
    rows = query.order_by(models.Item.sort, models.Item.id).all()
    return [schemas.ItemOut.model_validate(row) for row in rows]


def _assert_group(db: Session, user: models.User, group_id: int | None) -> None:
    if group_id is None:
        return
    group = db.get(models.Group, group_id)
    if group is None or group.user_id != user.id:
        raise HTTPException(status_code=400, detail="分组不存在或不属于当前账号")


def _next_sort(db: Session, user: models.User, group_id: int | None) -> int:
    query = db.query(func.coalesce(func.max(models.Item.sort), 0)).filter(
        models.Item.user_id == user.id
    )
    query = (
        query.filter(models.Item.group_id.is_(None))
        if group_id is None
        else query.filter(models.Item.group_id == group_id)
    )
    return int(query.scalar() or 0) + 1


@router.post("", response_model=schemas.ItemOut, status_code=status.HTTP_201_CREATED)
def create_item(
    payload: schemas.ItemIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.ItemOut:
    _assert_group(db, user, payload.group_id)
    item = models.Item(
        user_id=user.id,
        group_id=payload.group_id,
        title=payload.title.strip(),
        url=payload.url,
        lan_url=payload.lan_url,
        description=payload.description.strip(),
        icon=payload.icon.strip(),
        open_method=payload.open_method,
        login_required=payload.login_required,
        icon_bordered=payload.icon_bordered,
        sort=_next_sort(db, user, payload.group_id),
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    cache.invalidate_user(user.id)
    return schemas.ItemOut.model_validate(item)


def _get_owned(db: Session, user: models.User, item_id: int) -> models.Item:
    item = db.get(models.Item, item_id)
    if item is None or item.user_id != user.id:
        raise HTTPException(status_code=404, detail="卡片不存在")
    return item


@router.patch("/{item_id}", response_model=schemas.ItemOut)
def update_item(
    item_id: int,
    payload: schemas.ItemUpdate,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> schemas.ItemOut:
    item = _get_owned(db, user, item_id)
    data = payload.model_dump(exclude_unset=True)
    if "group_id" in data:
        _assert_group(db, user, data["group_id"])
        if data["group_id"] != item.group_id:
            data["sort"] = _next_sort(db, user, data["group_id"])
    for field, value in data.items():
        setattr(item, field, value.strip() if isinstance(value, str) else value)
    db.add(item)
    db.commit()
    db.refresh(item)
    cache.invalidate_user(user.id)
    return schemas.ItemOut.model_validate(item)


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_item(
    item_id: int,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> None:
    item = _get_owned(db, user, item_id)
    db.delete(item)
    db.commit()
    cache.invalidate_user(user.id)


@router.post("/reorder", status_code=status.HTTP_204_NO_CONTENT)
def reorder_items(
    payload: schemas.ReorderIn,
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> None:
    if not payload.ids:
        return
    rows = (
        db.query(models.Item)
        .filter(models.Item.user_id == user.id, models.Item.id.in_(payload.ids))
        .all()
    )
    owned = {row.id: row for row in rows}
    if set(payload.ids) - owned.keys():
        raise HTTPException(status_code=400, detail="包含不属于当前账号的卡片")
    for index, item_id in enumerate(payload.ids):
        owned[item_id].sort = index
    db.commit()
    cache.invalidate_user(user.id)