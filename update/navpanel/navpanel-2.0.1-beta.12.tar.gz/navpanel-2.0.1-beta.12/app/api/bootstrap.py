"""登录后的首屏聚合接口：一次请求拿到身份、分组和卡片，减少首屏往返。"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session

from .. import cache, models, schemas
from ..db import get_db
from ..security import get_current_user

router = APIRouter(prefix="/api", tags=["bootstrap"])


@router.get("/bootstrap")
def bootstrap(
    user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    cached = cache.get_panel("boot", user.id)
    if cached is not None:
        return cached
    groups = (
        db.query(models.Group)
        .filter_by(user_id=user.id)
        .order_by(models.Group.sort, models.Group.id)
        .all()
    )
    items = (
        db.query(models.Item)
        .filter_by(user_id=user.id)
        .order_by(models.Item.sort, models.Item.id)
        .all()
    )
    payload = jsonable_encoder(
        {
            "user": schemas.UserOut.model_validate(user),
            "groups": [schemas.GroupOut.model_validate(row) for row in groups],
            "items": [schemas.ItemOut.model_validate(row) for row in items],
        }
    )
    cache.set_panel("boot", user.id, payload)
    return payload
