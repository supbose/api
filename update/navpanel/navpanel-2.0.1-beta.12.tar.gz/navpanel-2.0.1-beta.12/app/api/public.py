"""未登录访客的只读面板接口。

访客能否查看看两层开关：
1. 服务端环境变量 NAVPANEL_PUBLIC_MODE（全局总开关，关闭时访客一律看不到）；
2. 用户自己的 allow_guest 设置（面板里可关，关掉后只能看到登录页）。
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import case
from sqlalchemy.orm import Session

from .. import cache, config, models
from ..db import get_db

router = APIRouter(prefix="/api/public", tags=["public"])


def _resolve_user(db: Session, username: str | None) -> models.User | None:
    """不指定用户名时展示管理员（首次启动创建的账号）的面板。"""
    if username:
        return db.query(models.User).filter_by(username=username).first()
    # 一条查询里按「配置的管理员账号 → 管理员 → 最早创建」排序，避免多次往返
    preferred = case((models.User.username == config.ADMIN_USERNAME, 0), else_=1)
    return (
        db.query(models.User)
        .order_by(preferred, models.User.is_admin.desc(), models.User.id)
        .first()
    )


def _guest_allowed(user: models.User | None) -> bool:
    return bool(config.PUBLIC_MODE and user is not None and user.allow_guest)


@router.get("/meta")
def public_meta(db: Session = Depends(get_db)) -> dict:
    """前端启动时用它判断：未登录能否直接看板、要不要显示登录入口。"""
    user = _resolve_user(db, None)
    allowed = _guest_allowed(user)
    return {
        "allowed": allowed,
        "username": user.username if allowed else "",
        "public_mode": config.PUBLIC_MODE,
        # 访客视图沿用面板主人的搜索框显示设置
        "show_search": bool(user.show_search) if user else True,
    }


@router.get("/panel")
def public_panel(username: str | None = None, db: Session = Depends(get_db)) -> dict:
    if not config.PUBLIC_MODE:
        raise HTTPException(status_code=404, detail="公开访问未开启")
    user = _resolve_user(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="用户不存在")
    if not user.allow_guest:
        raise HTTPException(status_code=403, detail="面板主人已关闭访客查看")

    cached = cache.get_panel("public", user.id)
    if cached is not None:
        return cached

    groups = (
        db.query(models.Group)
        .filter_by(user_id=user.id)
        .order_by(models.Group.sort, models.Group.id)
        .all()
    )
    items = (
        db.query(models.Item)
        .filter_by(user_id=user.id)
        # 标了「必须登录查看」的卡片不能出现在访客面板里
        .filter(models.Item.login_required.is_(False))
        .order_by(models.Item.sort, models.Item.id)
        .all()
    )
    payload = {
        "user": user.username,
        # 访客视图沿用面板主人的搜索框、标题栏、卡片布局、每行卡片数与背景图设置
        "show_search": bool(user.show_search),
        "hide_topbar": bool(user.hide_topbar),
        "card_layout": user.card_layout,
        "card_columns": user.card_columns,
        "background_image": user.background_image,
        "background_opacity": user.background_opacity,
        "background_enabled": bool(user.background_enabled),
        "groups": [{"id": g.id, "title": g.title} for g in groups],
        # 公开视图不输出内网地址，避免把局域网拓扑泄露给访客
        "items": [
            {
                "id": i.id,
                "group_id": i.group_id,
                "title": i.title,
                "url": i.url,
                "lan_url": "",
                "description": i.description,
                "icon": i.icon,
                "open_method": i.open_method,
                "icon_bordered": bool(i.icon_bordered),
                "sort": i.sort,
            }
            for i in items
        ],
    }
    cache.set_panel("public", user.id, payload)
    return payload