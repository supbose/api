"""数据库连接与会话管理（SQLAlchemy，默认 SQLite，可用环境变量切换到 MySQL/PostgreSQL）。"""

from __future__ import annotations

import logging
import os
import secrets
from collections.abc import Iterator

from sqlalchemy import create_engine, event, inspect
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from . import config

logger = logging.getLogger(__name__)

config.DATA_DIR.mkdir(parents=True, exist_ok=True)
config.ICON_DIR.mkdir(parents=True, exist_ok=True)
config.BACKGROUND_DIR.mkdir(parents=True, exist_ok=True)
config.EXPORT_DIR.mkdir(parents=True, exist_ok=True)


class Base(DeclarativeBase):
    pass


IS_SQLITE = config.DATABASE_URL.startswith("sqlite")

engine = create_engine(
    config.DATABASE_URL,
    connect_args={"check_same_thread": False} if IS_SQLITE else {},
    pool_pre_ping=not IS_SQLITE,
    future=True,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


if IS_SQLITE:

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragma(dbapi_connection, _record) -> None:
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA busy_timeout=5000")
        cursor.close()


def init_db() -> None:
    """建表 + 首次启动创建管理员账号。幂等，可重复调用。"""
    from . import models  # noqa: F401  导入以注册模型元数据
    from .security import hash_password

    Base.metadata.create_all(engine)
    _migrate_site_defaults()
    _migrate_site_footer_length()
    _migrate_user_preferences()
    _migrate_item_preferences()
    _migrate_token_version()
    if IS_SQLITE:
        _migrate_users()
        _migrate_items()
    with SessionLocal() as db:
        exists = db.query(models.User).filter_by(username=config.ADMIN_USERNAME).first()
        if exists is None:
            # 未显式配置口令时生成一次性随机密码，避免 admin/admin123 直接暴露
            password = config.ADMIN_PASSWORD or secrets.token_urlsafe(12)
            db.add(
                models.User(
                    username=config.ADMIN_USERNAME,
                    password_hash=hash_password(password),
                    is_admin=True,
                )
            )
            db.commit()
            if not config.ADMIN_PASSWORD:
                _write_initial_password(password)


def _write_initial_password(password: str) -> None:
    path = config.DATA_DIR / "initial_admin_password.txt"
    path.write_text(
        f"账号：{config.ADMIN_USERNAME}\n初始密码：{password}\n登录后请立即修改密码。\n",
        encoding="utf-8",
    )
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    logger.warning(
        "已创建管理员账号 %s，初始密码：%s（已写入 %s，请登录后立即修改）",
        config.ADMIN_USERNAME,
        password,
        path,
    )


def _migrate_site_defaults() -> None:
    """旧版本把「NavPanel」当作站点标题的默认值写进了库。

    现在默认留空（设置里不填就不显示标题），因此把仍是这个历史默认值的那一行
    清空；管理员自己改成别的名字不受影响。
    """
    tables = set(inspect(engine).get_table_names())
    if "site_settings" not in tables:
        return
    with engine.begin() as conn:
        conn.exec_driver_sql(
            "UPDATE site_settings SET site_title = '' WHERE site_title = 'NavPanel'"
        )


def _migrate_site_footer_length() -> None:
    """把页脚列宽从 200 扩到 500。

    SQLite 的 VARCHAR 长度不参与写入校验，旧库无需改表；MySQL 与 PostgreSQL
    按各自的 ALTER 语法扩宽，已经是 500 的库直接跳过。
    """
    tables = set(inspect(engine).get_table_names())
    if "site_settings" not in tables or IS_SQLITE:
        return
    columns = {column["name"]: column for column in inspect(engine).get_columns("site_settings")}
    column = columns.get("footer_text")
    if column is None:
        return
    length = getattr(column["type"], "length", None)
    if length is None or length >= 500:
        return
    definition = "VARCHAR(500) NOT NULL DEFAULT ''"
    with engine.begin() as conn:
        if engine.dialect.name == "mysql":
            conn.exec_driver_sql(f"ALTER TABLE site_settings MODIFY footer_text {definition}")
        else:
            conn.exec_driver_sql(
                f"ALTER TABLE site_settings ALTER COLUMN footer_text TYPE {definition}"
            )


def _migrate_token_version() -> None:
    """给旧库补 token_version 列（SQLite/MySQL/PostgreSQL 通用）。"""
    existing = {column["name"] for column in inspect(engine).get_columns("users")}
    if "token_version" in existing:
        return
    with engine.begin() as conn:
        conn.exec_driver_sql(
            "ALTER TABLE users ADD COLUMN token_version INTEGER NOT NULL DEFAULT 0"
        )


def _migrate_user_preferences() -> None:
    """给旧库补新增的偏好列；ADD COLUMN 语法在 SQLite/MySQL/PostgreSQL 通用。"""
    columns = {
        "card_popup_style": "VARCHAR(16) NOT NULL DEFAULT 'modal'",
        "card_layout": "VARCHAR(16) NOT NULL DEFAULT 'center'",
        "card_columns": "INTEGER NOT NULL DEFAULT 0",
        "background_image": "VARCHAR(500) NOT NULL DEFAULT ''",
        "background_opacity": "INTEGER NOT NULL DEFAULT 100",
        "background_enabled": "BOOLEAN NOT NULL DEFAULT 1",
        "hide_topbar": "BOOLEAN NOT NULL DEFAULT 0",
    }
    existing = {column["name"] for column in inspect(engine).get_columns("users")}
    with engine.begin() as conn:
        for name, ddl in columns.items():
            if name not in existing:
                conn.exec_driver_sql(f"ALTER TABLE users ADD COLUMN {name} {ddl}")


def _migrate_item_preferences() -> None:
    """给旧库补 icon_bordered 列；ADD COLUMN 语法在 SQLite/MySQL/PostgreSQL 通用。"""
    existing = {column["name"] for column in inspect(engine).get_columns("items")}
    if "icon_bordered" in existing:
        return
    with engine.begin() as conn:
        conn.exec_driver_sql(
            "ALTER TABLE items ADD COLUMN icon_bordered BOOLEAN NOT NULL DEFAULT 0"
        )


def _migrate_users() -> None:
    """给旧库补新增的布尔开关列（create_all 不会修改已存在的表）。"""
    switches = ("allow_guest", "show_search")
    with engine.begin() as conn:
        existing = {row[1] for row in conn.exec_driver_sql("PRAGMA table_info(users)")}
        for column in switches:
            if column not in existing:
                conn.exec_driver_sql(
                    f"ALTER TABLE users ADD COLUMN {column} BOOLEAN NOT NULL DEFAULT 1"
                )


def _migrate_items() -> None:
    """给旧库的 items 表补 login_required 列与复合索引。"""
    with engine.begin() as conn:
        existing = {row[1] for row in conn.exec_driver_sql("PRAGMA table_info(items)")}
        if "login_required" not in existing:
            conn.exec_driver_sql(
                "ALTER TABLE items ADD COLUMN login_required BOOLEAN NOT NULL DEFAULT 0"
            )
        # create_all 只对新表生效，旧库在这里补建索引
        conn.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_items_user_group_sort "
            "ON items (user_id, group_id, sort)"
        )

def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()