"""可选的 Redis 能力：面板缓存、图标抓取限流、登录令牌存储。

未配置 NAVPANEL_REDIS_URL 时全部能力关闭（空操作），也不会导入 redis 依赖；
配置后启动时 ping 一次，连不上则整体回退为无 Redis 模式，不影响服务启动。
"""

from __future__ import annotations

import json
import logging
import time

from . import config

logger = logging.getLogger(__name__)

_client = None


def init() -> bool:
    """按需连接 Redis；失败时所有能力保持关闭。"""
    global _client
    if not config.REDIS_URL:
        return False
    try:
        import redis
    except ImportError:
        logger.warning("已配置 NAVPANEL_REDIS_URL 但缺少 redis 客户端：pip install redis")
        return False
    try:
        client = redis.Redis.from_url(
            config.REDIS_URL, decode_responses=True, socket_timeout=2
        )
        client.ping()
    except Exception as exc:  # 连接失败属于外部边界，回退即可
        logger.warning("Redis 连接失败，已回退为无 Redis 模式：%s", exc)
        return False
    _client = client
    logger.info("Redis 已启用：面板缓存 / 图标限流 / 登录令牌存储")
    return True


def enabled() -> bool:
    return _client is not None


def _panel_key(kind: str, user_id: int) -> str:
    return f"navpanel:panel:{kind}:{user_id}"


def get_panel(kind: str, user_id: int) -> dict | None:
    if _client is None:
        return None
    try:
        raw = _client.get(_panel_key(kind, user_id))
    except Exception:
        return None
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


def set_panel(kind: str, user_id: int, payload: dict) -> None:
    if _client is None:
        return
    try:
        _client.setex(
            _panel_key(kind, user_id),
            config.CACHE_TTL_SECONDS,
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        )
    except Exception:
        pass


def invalidate_user(user_id: int) -> None:
    """任何写操作后清掉该账号的面板缓存。"""
    if _client is None:
        return
    try:
        _client.delete(_panel_key("boot", user_id), _panel_key("public", user_id))
    except Exception:
        pass


def allow_icon_fetch(ip: str) -> bool:
    """按小时窗口限制每个来源 IP 的图标抓取次数；Redis 关闭时不做限制。"""
    if _client is None:
        return True
    key = f"navpanel:icons:{ip}:{int(time.time() // 3600)}"
    try:
        count = _client.incr(key)
        if count == 1:
            _client.expire(key, 3600)
        return count <= config.ICON_FETCH_LIMIT
    except Exception:
        return True


def _login_key(ip: str) -> str:
    return f"navpanel:login:{ip}"


def login_failures(ip: str) -> int:
    """当前窗口内该 IP 的登录失败次数；Redis 关闭时返回 0（由进程内兜底）。"""
    if _client is None:
        return 0
    try:
        return int(_client.get(_login_key(ip)) or 0)
    except Exception:
        return 0


def record_login_failure(ip: str, window_seconds: int) -> None:
    if _client is None:
        return
    try:
        count = _client.incr(_login_key(ip))
        if count == 1:
            _client.expire(_login_key(ip), window_seconds)
    except Exception:
        pass


def clear_login_failures(ip: str) -> None:
    if _client is None:
        return
    try:
        _client.delete(_login_key(ip))
    except Exception:
        pass


def _session_key(jti: str) -> str:
    return f"navpanel:session:{jti}"


def store_session(jti: str, user_id: int, ttl: int) -> None:
    if _client is None or not jti:
        return
    try:
        _client.setex(_session_key(jti), ttl, str(user_id))
    except Exception:
        pass


def session_valid(jti: str) -> bool:
    if _client is None:
        return True
    if not jti:
        return False
    try:
        return bool(_client.exists(_session_key(jti)))
    except Exception:
        # Redis 故障时退回纯 JWT 校验，避免全员掉线
        return True


def drop_session(jti: str) -> None:
    if _client is None or not jti:
        return
    try:
        _client.delete(_session_key(jti))
    except Exception:
        pass
