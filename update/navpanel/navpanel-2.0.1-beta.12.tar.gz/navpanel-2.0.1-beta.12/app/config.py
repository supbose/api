"""运行配置。

全部来自环境变量，未配置时使用适合本地试跑的默认值；不依赖 pydantic-settings，
保证 `pip install -r requirements.txt` 之后没有额外安装步骤。
"""

from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    """极简 .env 读取：只支持 KEY=VALUE 与 # 注释，已存在的环境变量优先。"""
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if not key or key in os.environ:
            continue
        os.environ[key] = value.strip().strip('"').strip("'")


_load_dotenv(BASE_DIR / ".env")

DATA_DIR = Path(os.environ.get("NAVPANEL_DATA_DIR") or (BASE_DIR / "data")).expanduser()
ICON_DIR = DATA_DIR / "icons"
BACKGROUND_DIR = DATA_DIR / "backgrounds"
# 数据库转换产出的 SQLite 文件（也允许把目标路径指向数据目录内的其他位置）
EXPORT_DIR = DATA_DIR / "exports"
DB_PATH = Path(os.environ.get("NAVPANEL_DB_PATH") or (DATA_DIR / "navpanel.db"))
SECRET_FILE = DATA_DIR / "secret.key"
# Web 静态目录：默认用开发源文件 web/；发布时把 NAVPANEL_WEB_DIR 指到压缩产物，
# 例如 NAVPANEL_WEB_DIR=dist/web。相对路径按项目根目录解析。
_web_dir = os.environ.get("NAVPANEL_WEB_DIR", "").strip()
WEB_DIR = Path(_web_dir).expanduser() if _web_dir else BASE_DIR / "web"
if not WEB_DIR.is_absolute():
    WEB_DIR = BASE_DIR / WEB_DIR

# 前端版本：html = web/ 下的原生页面；react = frontend/ 的 Vite 构建产物。
# 配置非法直接启动失败，不做静默兜底，避免线上跑成预期之外的版本。
FRONTEND = os.environ.get("NAVPANEL_FRONTEND", "html").strip().lower() or "html"
if FRONTEND not in {"html", "react"}:
    raise RuntimeError("NAVPANEL_FRONTEND 只能是 html 或 react")
REACT_DIST_DIR = Path(
    os.environ.get("NAVPANEL_REACT_DIR") or (BASE_DIR / "frontend" / "dist")
).expanduser()

# 默认用本地 SQLite；设置 NAVPANEL_DATABASE_URL 可切到 MySQL / PostgreSQL
DATABASE_URL = (
    os.environ.get("NAVPANEL_DATABASE_URL", "").strip()
    or f"sqlite:///{DB_PATH.as_posix()}"
)

# Redis 完全可选：留空即关闭面板缓存、图标限流与令牌存储
REDIS_URL = os.environ.get("NAVPANEL_REDIS_URL", "").strip()
CACHE_TTL_SECONDS = int(os.environ.get("NAVPANEL_CACHE_TTL_SECONDS", "30"))
ICON_FETCH_LIMIT = int(os.environ.get("NAVPANEL_ICON_FETCH_LIMIT", "30"))

SECRET_KEY = os.environ.get("NAVPANEL_SECRET_KEY", "").strip()
TOKEN_TTL_HOURS = int(os.environ.get("NAVPANEL_TOKEN_TTL_HOURS", "24"))

ADMIN_USERNAME = os.environ.get("NAVPANEL_ADMIN_USERNAME", "admin")
# 留空表示首次启动自动生成随机密码（写入 data/initial_admin_password.txt 并打印到日志）
ADMIN_PASSWORD = os.environ.get("NAVPANEL_ADMIN_PASSWORD", "").strip()

PUBLIC_MODE = os.environ.get("NAVPANEL_PUBLIC_MODE", "1") == "1"
ALLOW_PRIVATE_ICON_HOSTS = os.environ.get("NAVPANEL_ALLOW_PRIVATE_ICONS", "0") == "1"

# 整页背景图上传限制
BACKGROUND_MAX_BYTES = 8 * 1024 * 1024

# 图标抓取的限制（防 SSRF 之余也要防止被大文件拖死）
ICON_MAX_BYTES = 512 * 1024
ICON_PAGE_MAX_BYTES = 256 * 1024
ICON_TIMEOUT_SECONDS = 8.0
ICON_MAX_REDIRECTS = 3
ICON_USER_AGENT = "NavPanel/0.1 (+https://example.local)"