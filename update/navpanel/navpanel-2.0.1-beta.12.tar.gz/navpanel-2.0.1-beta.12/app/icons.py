"""图标抓取与缓存。

安全要点（防 SSRF）：
1. 只允许 http/https；
2. 解析域名后逐个 IP 检查，`is_global` 为假的一律拒绝——内网、回环、
   链路本地（含 169.254.169.254 云元数据地址）、保留段全部挡掉；
3. 手动跟随重定向（最多 3 跳），每一跳都重新校验；
4. 限制响应体积与超时，避免被大文件或慢连接拖死；
5. 只接受位图（png/jpeg/gif/ico/webp/bmp），**拒收 SVG**——SVG 可以内嵌脚本，
   同源托管会变成存储型 XSS。
需要抓内网 NAS 图标时，显式设置 NAVPANEL_ALLOW_PRIVATE_ICONS=1。
"""

from __future__ import annotations

import hashlib
import io
import ipaddress
import re
import socket
import warnings
from urllib.parse import urljoin, urlparse

import httpx
from fastapi import HTTPException
from PIL import Image

from . import config

MAX_ICON_CANDIDATES = 6  # 单次抓取最多返回多少个候选图标供用户挑选

_IMAGE_EXT_BY_TYPE = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/gif": ".gif",
    "image/x-icon": ".ico",
    "image/vnd.microsoft.icon": ".ico",
    "image/webp": ".webp",
    "image/bmp": ".bmp",
}

_MAGIC_SIGNATURES: tuple[tuple[bytes, str], ...] = (
    (b"\x89PNG\r\n\x1a\n", ".png"),
    (b"\xff\xd8\xff", ".jpg"),
    (b"GIF87a", ".gif"),
    (b"GIF89a", ".gif"),
    (b"\x00\x00\x01\x00", ".ico"),
    (b"BM", ".bmp"),
)

_LINK_TAG_RE = re.compile(r"<link\b[^>]*>", re.IGNORECASE)
_ATTR_RE = re.compile(r"""([\w:-]+)\s*=\s*["']([^"']*)["']""", re.IGNORECASE)


def _assert_public_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise HTTPException(status_code=400, detail="只支持 http/https 地址")
    host = parsed.hostname
    if not host:
        raise HTTPException(status_code=400, detail="地址缺少主机名")
    if config.ALLOW_PRIVATE_ICON_HOSTS:
        return
    try:
        infos = socket.getaddrinfo(host, parsed.port or 80, proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise HTTPException(status_code=400, detail=f"域名解析失败: {host}") from exc
    for info in infos:
        address = info[4][0].split("%", 1)[0]
        try:
            ip = ipaddress.ip_address(address)
        except ValueError:
            continue
        mapped = getattr(ip, "ipv4_mapped", None)
        if mapped is not None:
            ip = mapped
        if not ip.is_global:
            raise HTTPException(
                status_code=400,
                detail=f"拒绝抓取内网或保留地址（{address}）",
            )


def _detect_ext(content: bytes, content_type: str) -> str | None:
    for magic, ext in _MAGIC_SIGNATURES:
        if content.startswith(magic):
            return ext
    if content[:4] == b"RIFF" and content[8:12] == b"WEBP":
        return ".webp"
    ext = _IMAGE_EXT_BY_TYPE.get(content_type)
    if ext in {".png", ".jpg", ".gif", ".ico", ".webp", ".bmp"}:
        return ext
    return None


def _request(
    client: httpx.Client, url: str, *, max_bytes: int, accept: str
) -> tuple[bytes, str, str]:
    """带重定向校验的 GET，返回 (内容, content-type, 最终地址)。"""
    current = url
    for _ in range(config.ICON_MAX_REDIRECTS + 1):
        _assert_public_url(current)
        try:
            with client.stream("GET", current, headers={"Accept": accept}) as response:
                if response.status_code in {301, 302, 303, 307, 308}:
                    location = response.headers.get("location")
                    if not location:
                        raise HTTPException(status_code=400, detail="重定向缺少 Location")
                    current = urljoin(current, location)
                    continue
                if response.status_code >= 400:
                    raise HTTPException(
                        status_code=400,
                        detail=f"目标返回 HTTP {response.status_code}",
                    )
                content_type = (
                    response.headers.get("content-type", "").split(";")[0].strip().lower()
                )
                buffer = bytearray()
                for chunk in response.iter_bytes():
                    buffer.extend(chunk)
                    if len(buffer) > max_bytes:
                        raise HTTPException(
                            status_code=413, detail="目标内容超过体积上限"
                        )
                return bytes(buffer), content_type, str(response.url)
        except HTTPException:
            raise
        except httpx.HTTPError as exc:
            raise HTTPException(status_code=400, detail=f"抓取失败: {exc}") from exc
    raise HTTPException(status_code=400, detail="重定向次数过多")


def _candidate_icons(page_url: str, html: str) -> list[str]:
    candidates: list[str] = []
    for tag in _LINK_TAG_RE.findall(html):
        attrs = {name.lower(): value for name, value in _ATTR_RE.findall(tag)}
        rel = attrs.get("rel", "").lower()
        href = attrs.get("href", "").strip()
        if not href or "icon" not in rel:
            continue
        candidates.append(urljoin(page_url, href))
    # apple-touch-icon / 普通 icon 之外的兜底
    candidates.append(urljoin(page_url, "/favicon.ico"))
    seen: set[str] = set()
    ordered: list[str] = []
    for candidate in candidates:
        if candidate not in seen:
            seen.add(candidate)
            ordered.append(candidate)
    return ordered


# 单张图标允许的最大像素数，防止几百 KB 的小文件解压成超大位图（解码炸弹）
MAX_ICON_PIXELS = 4096 * 4096


def _shrink(content: bytes) -> tuple[bytes, str] | None:
    """把图标统一缩到 64×64 以内的 PNG；无法解码或尺寸异常时返回 None。"""
    try:
        with warnings.catch_warnings():
            # Pillow 默认只对大图发警告，这里升级为异常，统一按无效图标处理
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(content)) as image:
                if image.width * image.height > MAX_ICON_PIXELS:
                    return None
                image.thumbnail((64, 64), Image.LANCZOS)
                buffer = io.BytesIO()
                image.save(buffer, format="PNG", optimize=True)
                return buffer.getvalue(), ".png"
    except (Image.DecompressionBombError, Image.DecompressionBombWarning):
        return None
    except Exception:  # 外部图片可能损坏或格式特殊，解不开视为无效
        return None


def _store(content: bytes) -> str:
    prepared = _shrink(content)
    if prepared is None:
        raise HTTPException(status_code=415, detail="图标无法解析为有效位图")
    content, ext = prepared
    name = hashlib.sha256(content).hexdigest()[:24] + ext
    target = config.ICON_DIR / name
    if not target.exists():
        target.write_bytes(content)
    return f"/icons/{name}"


MAX_BACKGROUND_PIXELS = 8192 * 8192


def save_background(content: bytes) -> str:
    """校验并原样保存整页背景图（不缩放），返回 /backgrounds/<name>。"""
    ext = _detect_ext(content, "")
    if ext is None:
        raise HTTPException(status_code=415, detail="只支持位图格式（PNG/JPG/GIF/WebP/BMP）")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(content)) as image:
                if image.width * image.height > MAX_BACKGROUND_PIXELS:
                    raise HTTPException(status_code=413, detail="背景图分辨率过大")
                image.load()
    except HTTPException:
        raise
    except Exception:  # 解码失败、压缩炸弹等一律视为无效图片
        raise HTTPException(status_code=415, detail="背景图无法解析为有效位图") from None
    name = hashlib.sha256(content).hexdigest()[:24] + ext
    target = config.BACKGROUND_DIR / name
    if not target.exists():
        target.write_bytes(content)
    return f"/backgrounds/{name}"


def cache_icon(url: str) -> str:
    """把已有外链图标下载下来落盘，返回本地图标路径。

    与 `fetch_icons` 共用同一套 SSRF 校验、体积与格式限制，区别是这里
    直接请求图标地址本身，不再解析页面。
    """
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        raise HTTPException(status_code=400, detail="只支持 http/https 图标地址")
    with httpx.Client(
        timeout=config.ICON_TIMEOUT_SECONDS,
        headers={"User-Agent": config.ICON_USER_AGENT},
        follow_redirects=False,
        trust_env=False,
    ) as client:
        content, content_type, _ = _request(
            client, url, max_bytes=config.ICON_MAX_BYTES, accept="image/*"
        )
    ext = _detect_ext(content, content_type)
    if ext is None:
        raise HTTPException(status_code=415, detail="图标格式不受支持")
    return _store(content)


def fetch_icons(url: str) -> list[tuple[str, str]]:
    """抓取站点图标，返回去重后的候选列表 [(本地图标路径, 来源地址)]。

    页面里通常声明了多个尺寸或用途的图标，全部抓下来交给用户自己挑，
    上限 `MAX_ICON_CANDIDATES` 个，避免为一张卡片发起过多外部请求。
    """
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = f"https://{url}"
    _assert_public_url(url)

    with httpx.Client(
        timeout=config.ICON_TIMEOUT_SECONDS,
        headers={"User-Agent": config.ICON_USER_AGENT},
        follow_redirects=False,
        # 不读取 HTTP(S)_PROXY：否则实际连接由代理解析 DNS，可能绕过内网 IP 校验
        trust_env=False,
    ) as client:
        content, content_type, final_url = _request(
            client, url, max_bytes=config.ICON_PAGE_MAX_BYTES, accept="text/html,image/*"
        )
        if content_type.startswith("image/"):
            ext = _detect_ext(content, content_type)
            if ext is None:
                raise HTTPException(status_code=415, detail="不支持的图片格式")
            return [(_store(content), final_url)]

        html = content.decode("utf-8", errors="ignore")
        last_error: HTTPException | None = None
        results: list[tuple[str, str]] = []
        seen: set[str] = set()
        for candidate in _candidate_icons(final_url, html):
            if len(results) >= MAX_ICON_CANDIDATES:
                break
            try:
                icon_bytes, icon_type, icon_url = _request(
                    client, candidate, max_bytes=config.ICON_MAX_BYTES, accept="image/*"
                )
            except HTTPException as exc:
                last_error = exc
                continue
            ext = _detect_ext(icon_bytes, icon_type)
            if ext is None:
                last_error = HTTPException(status_code=415, detail="图标格式不受支持")
                continue
            try:
                stored = _store(icon_bytes)
            except HTTPException as exc:  # 损坏或解码炸弹：跳过该候选，不影响其他图标
                last_error = exc
                continue
            if stored in seen:  # 同一张图被声明多次（不同尺寸/rel）时只保留一份
                continue
            seen.add(stored)
            results.append((stored, icon_url))

        if results:
            return results
        raise last_error or HTTPException(
            status_code=404, detail="没有找到可用图标，可用首字母图标代替"
        )