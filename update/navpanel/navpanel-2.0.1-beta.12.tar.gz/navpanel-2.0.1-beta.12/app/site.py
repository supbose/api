"""站点级设置（网站标题、页脚版权信息）。

这两项与账号无关：登录页、访客视图、面板都要展示同一套标题与版权，
因此单独放在单行表 `site_settings`（id=1），由管理员在设置里修改。
读取走一次简单查询，不引入缓存，避免多进程下缓存不一致。
"""

from __future__ import annotations

from datetime import datetime, timezone
from html import escape
from html.parser import HTMLParser
from urllib.parse import urlsplit

from sqlalchemy.orm import Session

from . import models, schemas

# 默认留空：设置里不填就不显示标题与页脚，不再回退成产品名
DEFAULT_TITLE = ""
DEFAULT_FOOTER = ""
SITE_ROW_ID = 1

# 页脚只放版权行，够用的排版标签就这些；img/script/style/iframe 一律不开放
ALLOWED_TAGS = {"a", "b", "strong", "i", "em", "span", "br", "small"}
ALLOWED_ATTRS = {"a": {"href", "title", "target"}}
ALLOWED_LINK_SCHEMES = {"http", "https", "mailto", "tel"}
VOID_TAGS = {"br"}


def _safe_href(value: str) -> bool:
    """只放行 http/https/mailto/tel 与相对地址，挡掉 javascript: 与 data: 之类。"""
    value = (value or "").strip()
    if not value or value.lower().startswith("javascript:"):
        return False
    scheme = urlsplit(value).scheme
    return scheme.lower() in ALLOWED_LINK_SCHEMES if scheme else True


class _FooterSanitizer(HTMLParser):
    """白名单清洗：允许的标签原样输出（属性做过滤），其余标签丢掉但保留文字。"""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.open_tags: list[str] = []

    def handle_starttag(self, tag, attrs) -> None:
        tag = tag.lower()
        if tag in VOID_TAGS:
            self.parts.append(f"<{tag}>")
            return
        if tag not in ALLOWED_TAGS:
            return  # 标签本身丢弃，内部文字仍按文本保留
        self.parts.append(f"<{tag}{self._clean_attrs(tag, attrs)}>")
        self.open_tags.append(tag)

    def handle_startendtag(self, tag, attrs) -> None:
        self.handle_starttag(tag, attrs)
        if tag.lower() in self.open_tags:
            self.handle_endtag(tag)

    def handle_endtag(self, tag) -> None:
        tag = tag.lower()
        if tag not in self.open_tags:
            return
        index = len(self.open_tags) - 1 - self.open_tags[::-1].index(tag)
        del self.open_tags[index]
        self.parts.append(f"</{tag}>")

    def handle_data(self, data: str) -> None:
        self.parts.append(escape(data, quote=False))

    def result(self) -> str:
        # 输入里没闭合的标签在结尾补齐，避免脏 HTML 影响后面内容
        for tag in reversed(self.open_tags):
            self.parts.append(f"</{tag}>")
        self.open_tags.clear()
        return "".join(self.parts).strip()

    @staticmethod
    def _clean_attrs(tag: str, attrs) -> str:
        allowed = ALLOWED_ATTRS.get(tag, set())
        out: list[str] = []
        for name, value in attrs:
            name = name.lower()
            if name not in allowed or value is None:
                continue
            if name == "href":
                if not _safe_href(value):
                    continue
                out.append(f' href="{escape(value, quote=True)}"')
                # 外链默认加 rel，避免 window.opener 被利用
                out.append(' rel="noopener noreferrer"')
            elif name == "target":
                if value not in ("_blank", "_self"):
                    continue
                out.append(f' target="{value}"')
            else:  # title
                out.append(f' title="{escape(value, quote=True)}"')
        return "".join(out)


def sanitize_footer(html_text: str) -> str:
    """把页脚配置清洗成可安全插入 DOM 的 HTML；没有内容时返回空串。"""
    sanitizer = _FooterSanitizer()
    sanitizer.feed(html_text or "")
    sanitizer.close()
    return sanitizer.result()


def get_row(db: Session) -> models.SiteSetting:
    """取单行站点设置；首次访问时按默认值建行，后续直接复用。"""
    row = db.get(models.SiteSetting, SITE_ROW_ID)
    if row is None:
        row = models.SiteSetting(
            id=SITE_ROW_ID, site_title=DEFAULT_TITLE, footer_text=DEFAULT_FOOTER
        )
        db.add(row)
        db.commit()
        db.refresh(row)
    return row


def render_footer(text: str, year: int) -> str:
    """把页脚文本里的 {year} 换成当前年份；空文本返回空串，前端据此隐藏页脚。"""
    value = (text or "").strip()
    if not value:
        return ""
    return value.replace("{year}", str(year))


def payload(db: Session) -> schemas.SiteSettingsOut:
    row = get_row(db)
    year = datetime.now(timezone.utc).astimezone().year
    # 留空就是空：前端据此隐藏标题元素，不再补默认名
    title = (row.site_title or "").strip()
    template = (row.footer_text or "").strip()
    return schemas.SiteSettingsOut(
        title=title,
        footer=sanitize_footer(render_footer(template, year)),
        footer_template=template,
        year=year,
    )


def read_title(db: Session) -> str:
    """只取标题，供服务端渲染 <title> 用；出错时由调用方回退到默认值。"""
    return payload(db).title