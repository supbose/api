"""登录失败限流。

启用 Redis 时计数放在 Redis（多进程共享）；未启用时退回进程内滑动窗口，
保证默认部署也有基本的暴力破解防护。只按来源 IP 计数，不信任可伪造的
X-Forwarded-For；反向代理场景应在代理侧做限流。
"""

from __future__ import annotations

import threading
import time
from collections import deque

from . import cache

WINDOW_SECONDS = 15 * 60
MAX_FAILURES = 10

_lock = threading.Lock()
_failures: dict[str, deque[float]] = {}


def _recent(ip: str) -> deque[float]:
    """返回该 IP 在窗口内的失败时间戳，顺带丢弃过期记录。"""
    now = time.monotonic()
    queue = _failures.setdefault(ip, deque())
    while queue and now - queue[0] > WINDOW_SECONDS:
        queue.popleft()
    return queue


def blocked(ip: str) -> bool:
    if cache.enabled():
        return cache.login_failures(ip) >= MAX_FAILURES
    with _lock:
        return len(_recent(ip)) >= MAX_FAILURES


def record_failure(ip: str) -> None:
    if cache.enabled():
        cache.record_login_failure(ip, WINDOW_SECONDS)
        return
    with _lock:
        _recent(ip).append(time.monotonic())


def reset(ip: str) -> None:
    if cache.enabled():
        cache.clear_login_failures(ip)
        return
    with _lock:
        _failures.pop(ip, None)
