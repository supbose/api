#!/usr/bin/env bash
# NavPanel 安装向导（交互界面）
#
# 入口：sudo bash deploy/install-wizard.sh
#      或 sudo bash deploy/install.sh（无参数且在终端里会自动进本向导）
#
# 菜单：安装/升级、卸载。安装流程可设置代码/数据目录、端口、管理员账号与口令、
# pip 镜像源、站点域名，以及是否开启 Let's Encrypt HTTPS。
#
# 非交互环境（CI、管道）不要用本脚本，直接调 deploy/install.sh 带参数即可。

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
INSTALLER="$BASE_DIR/deploy/install.sh"
UNINSTALLER="$BASE_DIR/deploy/uninstall.sh"

INSTALL_DIR="${INSTALL_DIR:-/opt/navpanel}"
DATA_DIR="${DATA_DIR:-/var/lib/navpanel}"
PORT="${PORT:-8000}"
ADMIN_USER="${ADMIN_USERNAME:-admin}"
ADMIN_PASS=""
PIP_INDEX=""
PIP_LABEL="PyPI 官方"
DOMAIN=""
ENABLE_SSL=0
NGINX_CONF_DIR="${NGINX_CONF_DIR:-/etc/nginx/conf.d}"
RELOAD_CMD="${RELOAD_CMD:-systemctl reload nginx}"
PASSTHRU=()

C_GREEN=$'\033[32m'; C_YELLOW=$'\033[33m'; C_RED=$'\033[31m'; C_DIM=$'\033[2m'; C_OFF=$'\033[0m'

say() { printf '%s==>%s %s\n' "$C_GREEN" "$C_OFF" "$*"; }
warn() { printf '%s[提示]%s %s\n' "$C_YELLOW" "$C_OFF" "$*"; }
fail() { printf '%s[失败]%s %s\n' "$C_RED" "$C_OFF" "$*" >&2; }
rule() { printf '%s%s%s\n' "$C_DIM" "------------------------------------------------------------" "$C_OFF"; }

# 有些环境（包括 systemd 精简 PATH）里 /usr/sbin 不在 PATH，因此先找 PATH 再找常见绝对路径
detect_cmd() { # detect_cmd 名称 [候选绝对路径...] → 输出可执行路径
  local name="$1" candidate
  shift
  if command -v "$name" >/dev/null 2>&1; then command -v "$name"; return 0; fi
  for candidate in "$@"; do
    [[ -x "$candidate" ]] && { printf '%s' "$candidate"; return 0; }
  done
  return 1
}

NGINX_BIN="$(detect_cmd nginx /usr/sbin/nginx /usr/local/sbin/nginx /usr/local/nginx/sbin/nginx)" || NGINX_BIN=""
CERTBOT_BIN="$(detect_cmd certbot /usr/bin/certbot /usr/local/bin/certbot)" || CERTBOT_BIN=""

usage() {
  cat <<'EOF'
NavPanel 安装向导

用法：
  sudo bash deploy/install-wizard.sh [参数]

参数（透传或覆盖默认值）：
  --no-user        不创建系统用户（已自备用户时）
  --no-systemd     只装代码，不装 systemd 单元
  --no-deps        跳过 pip 安装（离线/已预装依赖）
  --port PORT      预填监听端口
  --install-dir DIR / --data-dir DIR   预填目录
  --nginx-conf-dir DIR  站点配置输出目录，默认 /etc/nginx/conf.d
  --reload-cmd CMD     重载命令，默认 systemctl reload nginx
  -h, --help       显示本帮助
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-user|--no-systemd|--no-deps) PASSTHRU+=("$1"); shift ;;
    --port) PORT="${2:?缺端口}"; shift 2 ;;
    --install-dir) INSTALL_DIR="${2:?缺目录}"; shift 2 ;;
    --data-dir) DATA_DIR="${2:?缺目录}"; shift 2 ;;
    --nginx-conf-dir) NGINX_CONF_DIR="${2:?缺目录}"; shift 2 ;;
    --reload-cmd) RELOAD_CMD="${2:?缺命令}"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) fail "未知参数：$1（用 --help 看用法）"; exit 1 ;;
  esac
done

[[ ${EUID:-$(id -u)} -eq 0 ]] || { fail "需要 root 权限（sudo bash deploy/install-wizard.sh）"; exit 1; }
[[ -f "$INSTALLER" ]] || { fail "找不到安装脚本：$INSTALLER"; exit 1; }

# ---------- 交互原语（兼容管道输入，读不到就用默认值） ----------
ask() { # ask 提示 默认值
  local prompt="$1" default="${2:-}" answer
  printf '%s%s: ' "$prompt" "${default:+ [$default]}" >&2
  IFS= read -r answer || answer=""
  [[ -z "$answer" ]] && answer="$default"
  printf '%s' "$answer"
}

ask_secret() { # ask_secret 提示 → stdout（不回显）
  local prompt="$1" value
  printf '%s' "$prompt" >&2
  IFS= read -r -s value || value=""
  printf '\n' >&2
  printf '%s' "$value"
}

confirm() { # confirm 提示 默认 y/n
  local prompt="$1" default="${2:-y}" answer
  printf '%s [%s]: ' "$prompt" "$default" >&2
  IFS= read -r answer || answer=""
  answer="${answer:-$default}"
  [[ "$answer" =~ ^[Yy]([Ee][Ss])?$ ]]
}

# ---------- 站点配置 ----------
write_http_config() { # write_http_config 目标文件 域名
  local target="$1" domain="$2"
  cat >"$target" <<EOF
# 由 NavPanel 安装向导生成（仅 HTTP）。启用 HTTPS 请用 deploy/nginx-navpanel.conf
limit_req_zone \$binary_remote_addr zone=navpanel_login:10m rate=10r/m;

server {
    listen 80;
    server_name $domain;

    client_max_body_size 10m;

    proxy_http_version 1.1;
    proxy_set_header Host              \$host;
    proxy_set_header X-Real-IP         \$remote_addr;
    proxy_set_header X-Forwarded-For   \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;

    location / {
        proxy_pass http://127.0.0.1:$PORT;
    }

    location = /api/auth/login {
        limit_req zone=navpanel_login burst=5 nodelay;
        limit_req_status 429;
        proxy_pass http://127.0.0.1:$PORT;
    }
}
EOF
}

apply_site_config() { # apply_site_config 域名 是否SSL(0/1)
  local domain="$1" ssl="$2" target
  if [[ -z "$NGINX_BIN" ]]; then
    warn "未检测到 Nginx（PATH 与常见路径都没有），跳过站点配置。装好后可手动 cp deploy/nginx-navpanel.conf 并改域名"
    return 0
  fi
  target="$NGINX_CONF_DIR/navpanel.conf"
  mkdir -p "$NGINX_CONF_DIR"

  if [[ $ssl -eq 1 ]]; then
    if [[ -z "$CERTBOT_BIN" ]]; then
      warn "未安装 certbot：本次只写 HTTP 配置。装好 certbot 后可用 deploy/nginx-navpanel.conf + renew-cert.sh 开启 HTTPS"
      ssl=0
    fi
  fi

  if [[ $ssl -eq 1 ]]; then
    mkdir -p /var/www/certbot
    install -m 0644 "$BASE_DIR/deploy/nginx-navpanel.conf" "$target"
    sed -i "s/nav.example.com/$domain/g" "$target"
    say "申请 Let's Encrypt 证书：$domain"
    if "$CERTBOT_BIN" certonly --webroot -w /var/www/certbot -d "$domain" \
        --non-interactive --agree-tos --register-unsafely-without-email \
        --deploy-hook "$RELOAD_CMD"; then
      say "证书已签发：/etc/letsencrypt/live/$domain/"
    else
      warn "证书申请失败（域名未解析 / 80 端口不通 / 频率限制），先按 HTTP 提供访问"
      write_http_config "$target" "$domain"
      ssl=0
    fi
  else
    write_http_config "$target" "$domain"
  fi

  if "$NGINX_BIN" -t 2>/dev/null; then
    if $RELOAD_CMD; then say "站点已生效：$target"; else warn "重载失败，请手动执行：$RELOAD_CMD"; fi
  else
    warn "nginx -t 未通过，配置已写入 $target，请检查后再 reload"
  fi
  if [[ $ssl -eq 0 ]]; then
    warn "当前为 HTTP 站点；配置 HTTPS：装 certbot 后执行 deploy/renew-cert.sh 并换用 deploy/nginx-navpanel.conf"
  fi
}

# ---------- 安装流程 ----------
do_install() {
  say "安装 / 升级 NavPanel"
  rule
  INSTALL_DIR="$(ask '代码目录' "$INSTALL_DIR")"
  DATA_DIR="$(ask '数据目录（SQLite / 图标 / 背景图）' "$DATA_DIR")"
  PORT="$(ask '监听端口' "$PORT")"

  rule
  ADMIN_USER="$(ask '管理员账号' "$ADMIN_USER")"
  local pass1 pass2
  pass1="$(ask_secret '管理员口令（留空则随机生成，输入不显示）: ')"
  if [[ -n "$pass1" ]]; then
    pass2="$(ask_secret '再输入一次确认: ')"
    if [[ "$pass1" != "$pass2" ]]; then
      warn "两次输入不一致，口令改为随机生成"
      pass1=""
    fi
  fi
  ADMIN_PASS="$pass1"

  rule
  printf 'pip 镜像源：\n  1) PyPI 官方（默认）\n  2) 清华 TUNA（国内推荐）\n  3) 阿里云\n  4) 自定义地址\n' >&2
  local pick
  pick="$(ask '选择' '1')"
  case "$pick" in
    2) PIP_INDEX="https://pypi.tuna.tsinghua.edu.cn/simple"; PIP_LABEL="清华 TUNA" ;;
    3) PIP_INDEX="https://mirrors.aliyun.com/pypi/simple/"; PIP_LABEL="阿里云" ;;
    4) PIP_INDEX="$(ask '镜像源地址' '')"; PIP_LABEL="${PIP_INDEX:-自定义}" ;;
    *) PIP_INDEX=""; PIP_LABEL="PyPI 官方" ;;
  esac

  rule
  DOMAIN="$(ask '站点域名（留空跳过 Nginx 站点配置）' '')"
  ENABLE_SSL=0
  if [[ -n "$DOMAIN" ]] && confirm "同时申请 Let's Encrypt 证书并开启 HTTPS？" "n"; then
    ENABLE_SSL=1
  fi

  rule
  cat >&2 <<EOF
即将安装：
  代码目录：$INSTALL_DIR
  数据目录：$DATA_DIR
  监听端口：$PORT（只监听 127.0.0.1）
  管理员：  $ADMIN_USER
  口令：    $([[ -n "$ADMIN_PASS" ]] && echo '按你输入的值' || echo '随机生成后打印')
  镜像源：  $PIP_LABEL
  域名：    ${DOMAIN:-未配置}
  HTTPS：   $( [[ $ENABLE_SSL -eq 1 ]] && echo 开启 || echo 关闭 )
EOF
  if ! confirm "开始安装？" "y"; then
    warn "已取消"
    return 0
  fi

  local args=(--install-dir "$INSTALL_DIR" --data-dir "$DATA_DIR" --port "$PORT" --admin-username "$ADMIN_USER")
  [[ -n "$ADMIN_PASS" ]] && args+=(--admin-password "$ADMIN_PASS")
  [[ -n "$PIP_INDEX" ]] && args+=(--pip-index "$PIP_INDEX")
  if ((${#PASSTHRU[@]})); then args+=("${PASSTHRU[@]}"); fi

  say "开始安装（详细输出见下）"
  if ! bash "$INSTALLER" "${args[@]}"; then
    fail "安装脚本返回失败，请查看上方输出"
    return 1
  fi

  if [[ -n "$DOMAIN" ]]; then
    rule
    apply_site_config "$DOMAIN" "$ENABLE_SSL"
  fi

  rule
  say "完成。常用命令："
  cat >&2 <<EOF
  查看状态： systemctl status navpanel
  查看日志： journalctl -u navpanel -n 50 -f
  配置 HTTPS（如未开启）：bash deploy/renew-cert.sh --install-timer
  卸载：     sudo bash deploy/install.sh（选 2）或 sudo bash deploy/uninstall.sh
EOF
}

# ---------- 卸载流程 ----------
do_uninstall() {
  say "卸载 NavPanel"
  rule
  INSTALL_DIR="$(ask '要卸载的代码目录' "$INSTALL_DIR")"
  DATA_DIR="$(ask '数据目录（默认保留）' "$DATA_DIR")"
  if [[ ! -d "$INSTALL_DIR" ]]; then
    warn "代码目录不存在：$INSTALL_DIR（可继续清理残留的 systemd 单元）"
  fi
  rule
  local args=(--install-dir "$INSTALL_DIR" --data-dir "$DATA_DIR")
  if confirm "删除数据目录 $DATA_DIR（SQLite、图标、背景图、密钥，不可恢复）？" "n"; then
    args+=(--purge-data)
  else
    warn "将保留数据目录：$DATA_DIR"
  fi
  if confirm "删除系统用户（如有）？" "n"; then
    args+=(--remove-user)
  fi
  bash "$UNINSTALLER" "${args[@]}"
}

menu() {
  rule
  printf 'NavPanel 安装向导\n'
  rule
  printf '  1) 安装 / 升级\n  2) 卸载\n  3) 退出\n'
}

while true; do
  menu
  choice="$(ask '请选择' '1')"
  case "$choice" in
    1) do_install ;;
    2) do_uninstall ;;
    3|q|Q) say "已退出"; exit 0 ;;
    *) warn "无效选项：$choice" ;;
  esac
  printf '\n'
done