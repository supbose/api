#!/usr/bin/env bash
# NavPanel Let's Encrypt 证书续期脚本
#
# 用法（root 执行，放在仓库根目录下调用）：
#   sudo bash deploy/renew-cert.sh                  # 立即检查并续期（到期前 30 天内才会真正续）
#   sudo bash deploy/renew-cert.sh --dry-run        # 演练：只验证 ACME 流程，不动现有证书
#   sudo bash deploy/renew-cert.sh --install-timer  # 装 systemd timer：每天两次随机延迟续期
#   sudo bash deploy/renew-cert.sh --help
#
# 默认走 webroot 校验（Nginx 配置里的 /.well-known/acme-challenge/ 指向 /var/www/certbot），
# 续期成功后执行 --reload-cmd（默认 systemctl reload nginx）让 Nginx 换上新证书。
#
# 首次签发不在本脚本范围内，命令示例：
#   sudo certbot certonly --webroot -w /var/www/certbot -d nav.example.com \
#        --deploy-hook 'systemctl reload nginx'

set -euo pipefail

SCRIPT_PATH="$(readlink -f "${BASH_SOURCE[0]}")"
WEBROOT="${WEBROOT:-/var/www/certbot}"
RELOAD_CMD="${RELOAD_CMD:-systemctl reload nginx}"
LOG_FILE="${LOG_FILE:-/var/log/navpanel-cert-renew.log}"
CERT_NAME="${CERT_NAME:-}"
TIMER_NAME="navpanel-cert-renew"
DRY_RUN=0
INSTALL_TIMER=0
QUIET=0

log() {
  local stamp
  stamp="$(date '+%Y-%m-%d %H:%M:%S')"
  printf '%s %s\n' "$stamp" "$*" >>"$LOG_FILE" 2>/dev/null || true
  [[ $QUIET -eq 1 ]] || printf '%s %s\n' "$stamp" "$*"
}
warn() { log "[警告] $*"; }
die() { log "[失败] $*"; exit 1; }

usage() {
  sed -n '2,15p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
  cat <<'EOF'

可选参数：
  --webroot DIR         ACME 校验目录，默认 /var/www/certbot（要能被 Nginx 访问到）
  --reload-cmd CMD      续期成功后的动作，默认 "systemctl reload nginx"
  --cert-name NAME      只处理指定证书名（certbot 里的名字，通常等于主域名）
  --log FILE            日志文件，默认 /var/log/navpanel-cert-renew.log
  --dry-run             演练模式，只验证流程不改证书
  --install-timer       安装并启用 systemd timer（每天 00:15 与 12:15，随机延迟 0-60 分钟）
  --quiet               不往终端输出，只写日志（适合放 timer / cron）
  -h, --help            显示本帮助

退出码：0 = 续期成功或无需续期；1 = 前置条件或 certbot 失败
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --webroot) WEBROOT="${2:?缺目录}"; shift 2 ;;
    --reload-cmd) RELOAD_CMD="${2:?缺命令}"; shift 2 ;;
    --cert-name) CERT_NAME="${2:?缺证书名}"; shift 2 ;;
    --log) LOG_FILE="${2:?缺文件}"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    --install-timer) INSTALL_TIMER=1; shift ;;
    --quiet) QUIET=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "未知参数：$1（用 --help 看用法）" ;;
  esac
done

[[ ${EUID:-$(id -u)} -eq 0 ]] || die "需要 root 权限（sudo bash deploy/renew-cert.sh）"
command -v certbot >/dev/null || die "未安装 certbot：apt install certbot（或 pip install certbot）"
command -v systemctl >/dev/null || warn "缺少 systemctl：续期后无法自动 reload，请手动重启 Nginx"

# 日志与校验目录
LOG_DIR="$(dirname "$LOG_FILE")"
[[ -d "$LOG_DIR" ]] || mkdir -p "$LOG_DIR"
[[ -f "$LOG_FILE" ]] || : >"$LOG_FILE"
chmod 600 "$LOG_FILE" 2>/dev/null || true
[[ -d "$WEBROOT" ]] || mkdir -p "$WEBROOT"
[[ -d "$WEBROOT" ]] || die "无法创建 webroot 目录：$WEBROOT"

# ---------- 安装 systemd timer ----------
if [[ $INSTALL_TIMER -eq 1 ]]; then
  UNIT_DIR="/etc/systemd/system"
  if [[ -e "/lib/systemd/system/certbot.timer" || -e "/usr/lib/systemd/system/certbot.timer" ]]; then
    warn "检测到 certbot 自带 timer，与 $TIMER_NAME.timer 功能重叠，二者保留其一即可（systemctl disable --now certbot.timer）"
  fi

  cat >"$UNIT_DIR/${TIMER_NAME}.service" <<EOF
[Unit]
Description=NavPanel Let's Encrypt 证书续期
Documentation=file:$(cd "$(dirname "$SCRIPT_PATH")/.." && pwd)/navpanel-deploy.md
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/env bash $SCRIPT_PATH --quiet --webroot $WEBROOT --reload-cmd "$RELOAD_CMD"${CERT_NAME:+ --cert-name $CERT_NAME}
# 续期失败不重试（ACME 有频率限制），等下一次 timer 触发
Nice=10
EOF

  cat >"$UNIT_DIR/${TIMER_NAME}.timer" <<EOF
[Unit]
Description=每日两次检查 NavPanel 证书续期

[Timer]
OnCalendar=*-*-* 00,12:15:00
RandomizedDelaySec=3600
Persistent=true

[Install]
WantedBy=timers.target
EOF

  chmod 0644 "$UNIT_DIR/${TIMER_NAME}.service" "$UNIT_DIR/${TIMER_NAME}.timer"
  systemctl daemon-reload
  systemctl enable "${TIMER_NAME}.timer" >/dev/null
  systemctl start "${TIMER_NAME}.timer"
  log "已安装并启用 ${TIMER_NAME}.timer（下次触发：$(systemctl show -p NextElapseUSecRealtime --value "${TIMER_NAME}.timer" 2>/dev/null || echo '见 systemctl list-timers')）"
  log "查看状态：systemctl list-timers ${TIMER_NAME}.timer / journalctl -u ${TIMER_NAME}.service"
  exit 0
fi

# ---------- 续期 ----------
ARGS=(renew --webroot --webroot-path "$WEBROOT" --non-interactive --deploy-hook "$RELOAD_CMD")
[[ -n "$CERT_NAME" ]] && ARGS+=(--cert-name "$CERT_NAME")
[[ $DRY_RUN -eq 1 ]] && ARGS+=(--dry-run)

log "开始续期：certbot ${ARGS[*]}"
set +e
OUTPUT="$(certbot "${ARGS[@]}" 2>&1)"
CODE=$?
set -e
printf '%s\n' "$OUTPUT" >>"$LOG_FILE"
[[ $QUIET -eq 1 ]] || printf '%s\n' "$OUTPUT"

if [[ $CODE -ne 0 ]]; then
  die "certbot 退出码 $CODE（可看 $LOG_FILE 或 certbot 日志 /var/log/letsencrypt/）"
fi

# certbot 的三种正常结果
if grep -qiE "Congratulations, all renewals succeeded|Successfully renewed" <<<"$OUTPUT"; then
  log "续期完成，已执行 reload：$RELOAD_CMD"
elif grep -qi "No renewals were attempted" <<<"$OUTPUT"; then
  log "无需续期（证书仍在有效期内，certbot 会在到期前 30 天内自动续）"
elif [[ $DRY_RUN -eq 1 ]]; then
  log "演练结束（dry-run 不会真正换证书，也会跳过 deploy hook）"
else
  log "certbot 执行完成，未匹配到续期关键字，请核对日志"
fi

# 顺带打印剩余有效期，方便判断是否真的要关注
if command -v openssl >/dev/null; then
  for cert in /etc/letsencrypt/live/*/fullchain.pem; do
    [[ -f "$cert" ]] || continue
    end="$(openssl x509 -enddate -noout -in "$cert" 2>/dev/null | cut -d= -f2)"
    [[ -n "$end" ]] && log "$(basename "$(dirname "$cert")") 证书到期：$end"
  done
fi

exit 0