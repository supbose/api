#!/usr/bin/env bash
# NavPanel 卸载脚本
#
# 用法（root）：
#   sudo bash deploy/uninstall.sh                    # 交互确认；数据目录保留
#   sudo bash deploy/uninstall.sh --yes              # 不询问，删除服务与代码，保留数据
#   sudo bash deploy/uninstall.sh --yes --purge-data # 连数据目录一起删（不可恢复）
#
# 默认行为：停服务 → 禁用并删除 systemd 单元 → 删除代码目录（含 .venv 与 dist）
# 数据目录（SQLite / 图标 / 背景图 / secret.key）默认保留，避免误删业务数据。

set -euo pipefail

SERVICE_NAME="${SERVICE_NAME:-navpanel}"
INSTALL_DIR="${INSTALL_DIR:-/opt/navpanel}"
DATA_DIR="${DATA_DIR:-/var/lib/navpanel}"
RUN_USER="${RUN_USER:-navpanel}"
ASSUME_YES=0
PURGE_DATA=0
REMOVE_USER=0

log() { printf '\033[32m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[33m[警告]\033[0m %s\n' "$*"; }
die() { printf '\033[31m[失败]\033[0m %s\n' "$*" >&2; exit 1; }

usage() {
  cat <<'EOF'
NavPanel 卸载脚本

用法：
  sudo bash deploy/uninstall.sh [参数]

参数：
  --service NAME     systemd 单元名，默认 navpanel
  --install-dir DIR  代码目录，默认 /opt/navpanel
  --data-dir DIR     数据目录，默认 /var/lib/navpanel
  --run-user USER    运行用户，默认 navpanel（配 --remove-user 才删）
  --purge-data       删除数据目录（SQLite、图标、背景图、secret.key，不可恢复）
  --remove-user      删除系统用户（仅在确认没有其他服务使用该用户时）
  --yes              不做交互确认
  -h, --help         显示本帮助
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --service) SERVICE_NAME="${2:?}"; shift 2 ;;
    --install-dir) INSTALL_DIR="${2:?}"; shift 2 ;;
    --data-dir) DATA_DIR="${2:?}"; shift 2 ;;
    --run-user) RUN_USER="${2:?}"; shift 2 ;;
    --purge-data) PURGE_DATA=1; shift ;;
    --remove-user) REMOVE_USER=1; shift ;;
    --yes) ASSUME_YES=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) die "未知参数：$1（用 --help 看用法）" ;;
  esac
done

[[ ${EUID:-$(id -u)} -eq 0 ]] || die "需要 root 权限（sudo bash deploy/uninstall.sh）"

confirm() { # confirm 提示 默认值(y/n)
  local prompt="$1" default="${2:-n}" answer
  [[ $ASSUME_YES -eq 1 ]] && return 0
  printf '%s [%s]: ' "$prompt" "$default" >&2
  read -r answer || true
  answer="${answer:-$default}"
  [[ "$answer" =~ ^[Yy]([Ee][Ss])?$ ]]
}

confirm "确认卸载 NavPanel？代码目录 $INSTALL_DIR 将被删除（数据目录默认保留）" "n" \
  || { log "已取消"; exit 0; }

# 1) 停服务
if command -v systemctl >/dev/null 2>&1 && [[ -f "/etc/systemd/system/${SERVICE_NAME}.service" ]]; then
  log "停止并禁用 ${SERVICE_NAME}"
  systemctl stop "$SERVICE_NAME" 2>/dev/null || true
  systemctl disable "$SERVICE_NAME" 2>/dev/null || true
  rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
  systemctl daemon-reload
  systemctl reset-failed "$SERVICE_NAME" 2>/dev/null || true
else
  warn "未发现 ${SERVICE_NAME}.service，跳过服务停止"
fi

# 2) 删代码目录
if [[ -d "$INSTALL_DIR" ]]; then
  log "删除代码目录 $INSTALL_DIR"
  rm -rf -- "$INSTALL_DIR"
else
  warn "代码目录不存在：$INSTALL_DIR"
fi

# 3) 数据目录
if [[ -d "$DATA_DIR" ]]; then
  if [[ $PURGE_DATA -eq 1 ]]; then
    if [[ $ASSUME_YES -eq 0 ]] && ! confirm "删除数据目录 $DATA_DIR？此操作不可恢复，输入 y 确认" "n"; then
      warn "已保留数据目录：$DATA_DIR"
    else
      log "删除数据目录 $DATA_DIR"
      rm -rf -- "$DATA_DIR"
    fi
  else
    log "保留数据目录：$DATA_DIR（如需清除：--purge-data）"
  fi
fi

# 4) 用户
if [[ $REMOVE_USER -eq 1 ]] && id -u "$RUN_USER" >/dev/null 2>&1; then
  if command -v userdel >/dev/null 2>&1; then
    log "删除系统用户 $RUN_USER"
    userdel "$RUN_USER" 2>/dev/null || warn "userdel 失败，请手动处理"
  else
    warn "缺少 userdel，未删除用户 $RUN_USER"
  fi
fi

if [[ -d "$DATA_DIR" ]]; then
  data_state="保留 ${DATA_DIR}"
else
  data_state="已删除或不存在（${DATA_DIR}）"
fi

cat <<EOF

$(log "卸载完成")
  已移除：systemd 单元、代码目录 ${INSTALL_DIR}
  数据目录：${data_state}
  Nginx 站点配置（如已配过）未自动删除：/etc/nginx/conf.d/navpanel.conf
EOF