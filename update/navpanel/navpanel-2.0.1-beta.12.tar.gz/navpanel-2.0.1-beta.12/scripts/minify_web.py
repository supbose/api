"""压缩 web/ 下的 CSS、JS、HTML，产出发布用的生产版本。

只覆盖 HTML 版前端（web/）。React 版（frontend/）由 vite build 自带压缩，不经过本脚本。

默认把压缩结果写到 dist/web/（与开发源目录 web/ 分离，dist/ 已在 .gitignore 里），
应用通过 NAVPANEL_WEB_DIR 指到产物即可使用：

    NAVPANEL_WEB_DIR=dist/web python -m uvicorn app.main:app

用法：
    python scripts/minify_web.py            # 重建 dist/web（npm run build:html）
    python scripts/minify_web.py --check    # 只校验产物与源文件是否同步（CI 用）
    python scripts/minify_web.py --keep     # 保留目标目录里源目录没有的文件

压缩策略是「保真优先」：JS 只删注释、行首缩进与行尾空白，保留换行（不碰 ASI）；
CSS 去掉注释与结构性空白，字符串与 calc() 里的必要空格不动；HTML 去掉注释、
折叠空白，但标签之间保留一个空格，避免行内元素文字粘连。
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SOURCE_DIR = BASE_DIR / "web"
DEST_DIR = BASE_DIR / "dist" / "web"
SUFFIXES = {".css", ".js", ".html"}

# 正则起点判定：这些字符/关键字后面出现 / 视为正则字面量而不是除号
REGEX_PREV_CHARS = set("(,=:[!&|?{};+-*%<>~^")
REGEX_PREV_WORDS = {
    "return",
    "typeof",
    "instanceof",
    "in",
    "of",
    "new",
    "delete",
    "void",
    "case",
    "do",
    "else",
    "throw",
    "yield",
    "await",
}


def _starts_regex(prev: str) -> bool:
    if not prev:
        return True
    if prev in REGEX_PREV_CHARS:
        return True
    return prev.isalpha() and prev in REGEX_PREV_WORDS


def minify_js(text: str) -> str:
    out: list[str] = []
    index = 0
    length = len(text)
    state = "normal"  # normal / string
    quote = ""
    at_line_start = True
    prev_word = ""

    while index < length:
        char = text[index]

        if state == "string":
            if char == "\\":
                out.append(text[index : index + 2])
                index += 2
                continue
            if char == quote:
                state = "normal"
            out.append(char)
            index += 1
            continue

        if at_line_start and char in " \t":
            index += 1
            continue

        if char in " \t":
            out.append(" ")
            index += 1
            while index < length and text[index] in " \t":
                index += 1
            continue

        if char == "\n":
            if out and out[-1] == " ":
                out.pop()
            out.append("\n")
            at_line_start = True
            prev_word = ""
            index += 1
            continue

        at_line_start = False

        if char == "/" and index + 1 < length:
            nxt = text[index + 1]
            if nxt == "/":
                end = text.find("\n", index)
                index = length if end == -1 else end
                continue
            if nxt == "*":
                end = text.find("*/", index + 2)
                index = length if end == -1 else end + 2
                out.append(" ")
                continue
            if _starts_regex(prev_word):
                cursor = index + 1
                in_class = False
                while cursor < length:
                    current = text[cursor]
                    if current == "\\":
                        cursor += 2
                        continue
                    if current == "[":
                        in_class = True
                    elif current == "]":
                        in_class = False
                    elif current == "/" and not in_class:
                        cursor += 1
                        break
                    elif current == "\n":
                        break
                    cursor += 1
                out.append(text[index:cursor])
                index = cursor
                prev_word = "/"
                continue

        if char in "'\"`":
            state = "string"
            quote = char
            out.append(char)
            index += 1
            continue

        out.append(char)
        if char.isalnum() or char in "_$":
            prev_word = (prev_word + char)[-12:] if char.isalnum() else char
        else:
            prev_word = char
        index += 1

    code = "".join(out)
    lines = [line for line in code.split("\n") if line.strip()]
    return "\n".join(lines) + ("\n" if lines else "")


def minify_css(text: str) -> str:
    parts: list[tuple[str, str]] = []
    buffer: list[str] = []
    index = 0
    length = len(text)

    while index < length:
        char = text[index]
        if char == "/" and index + 1 < length and text[index + 1] == "*":
            end = text.find("*/", index + 2)
            index = length if end == -1 else end + 2
            buffer.append(" ")
            continue
        if char in "\"'":
            quote = char
            cursor = index + 1
            while cursor < length:
                if text[cursor] == "\\":
                    cursor += 2
                    continue
                if text[cursor] == quote:
                    cursor += 1
                    break
                cursor += 1
            parts.append(("code", "".join(buffer)))
            buffer = []
            parts.append(("str", text[index:cursor]))
            index = cursor
            continue
        buffer.append(char)
        index += 1
    parts.append(("code", "".join(buffer)))

    chunks: list[str] = []
    for kind, content in parts:
        if kind == "str":
            chunks.append(content)
            continue
        code = re.sub(r"\s+", " ", content)
        # 只压缩结构性空白：calc() 里的 + / - 空格必须保留
        code = re.sub(r"\s*([{};:,>~])\s*", r"\1", code)
        code = re.sub(r";}", "}", code)
        chunks.append(code)

    return "".join(chunks).strip() + "\n"


def minify_html(text: str) -> str:
    stashed: list[str] = []

    def keep(match: re.Match[str]) -> str:
        stashed.append(match.group(0))
        return f"\x00{len(stashed) - 1}\x00"

    # 内联 script/style/pre/textarea 的内容原样保留
    text = re.sub(
        r"<(pre|textarea|script|style)\b[^>]*>.*?</\1\s*>",
        keep,
        text,
        flags=re.S | re.I,
    )
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    text = re.sub(r"[ \t]*\n[ \t]*", "\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    # 标签之间保留一个空格，避免行内元素文字粘在一起（如 <a>甲</a> <a>乙</a>）
    text = re.sub(r">\s+<", "> <", text)
    text = re.sub(r"\n{2,}", "\n", text).strip()

    for number, block in enumerate(stashed):
        text = text.replace(f"\x00{number}\x00", block)
    return text + "\n"


MINIFIERS = {".css": minify_css, ".js": minify_js, ".html": minify_html}


def collect(source: Path) -> list[Path]:
    return sorted(
        path
        for path in source.rglob("*")
        if path.is_file() and path.suffix.lower() in SUFFIXES
    )


def build(source: Path, dest: Path, keep: bool) -> list[tuple[str, int, int]]:
    if dest.exists() and not keep:
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)

    stats: list[tuple[str, int, int]] = []
    for path in collect(source):
        minifier = MINIFIERS[path.suffix.lower()]
        raw = path.read_text(encoding="utf-8")
        compressed = minifier(raw)
        target = dest / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(compressed, encoding="utf-8")
        stats.append(
            (str(path.relative_to(source)), len(raw.encode("utf-8")), len(compressed.encode("utf-8")))
        )
    return stats


def _display(path: Path) -> str:
    """展示用路径：项目内用相对路径，项目外（自定义 --dest）用绝对路径。"""
    try:
        return str(path.relative_to(BASE_DIR))
    except ValueError:
        return str(path)


def check(source: Path, dest: Path) -> int:
    problems = 0
    for path in collect(source):
        target = dest / path.relative_to(source)
        expected = MINIFIERS[path.suffix.lower()](path.read_text(encoding="utf-8"))
        if not target.exists():
            print(f"缺少产物：{_display(target)}")
            problems += 1
            continue
        if target.read_text(encoding="utf-8") != expected:
            print(f"产物与源文件不同步：{_display(target)}")
            problems += 1
    if problems:
        print(f"\n共 {problems} 个文件需要重新构建：python scripts/minify_web.py")
        return 1
    print(f"产物已是最新（{len(collect(source))} 个文件）")
    return 0


def report(stats: list[tuple[str, int, int]]) -> None:
    width = max((len(name) for name, _, _ in stats), default=4)
    total_raw = sum(raw for _, raw, _ in stats)
    total_min = sum(minified for _, _, minified in stats)
    print(f"{'文件':<{width}}  {'原大小':>10}  {'压缩后':>10}  {'减少':>8}")
    for name, raw, minified in stats:
        saved = (1 - minified / raw) * 100 if raw else 0
        print(f"{name:<{width}}  {raw / 1024:>9.1f}K  {minified / 1024:>9.1f}K  {saved:>7.1f}%")
    saved_total = (1 - total_min / total_raw) * 100 if total_raw else 0
    print("-" * (width + 44))
    print(
        f"{'合计':<{width}}  {total_raw / 1024:>9.1f}K  {total_min / 1024:>9.1f}K  {saved_total:>7.1f}%"
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="压缩 HTML 版前端 web/ 的 CSS、JS、HTML 生成生产版本")
    parser.add_argument("--source", default=str(SOURCE_DIR), help="源目录，默认 web/")
    parser.add_argument("--dest", default=str(DEST_DIR), help="产物目录，默认 dist/web/")
    parser.add_argument("--check", action="store_true", help="只校验产物是否与源文件同步")
    parser.add_argument("--keep", action="store_true", help="保留产物目录里源目录没有的文件")
    args = parser.parse_args(argv)

    source = Path(args.source).expanduser()
    dest = Path(args.dest).expanduser()
    if not source.is_dir():
        print(f"源目录不存在：{source}", file=sys.stderr)
        return 1

    if args.check:
        return check(source, dest)

    stats = build(source, dest, keep=args.keep)
    if not stats:
        print(f"没有可压缩的文件（{source}）", file=sys.stderr)
        return 1
    report(stats)
    print(f"\n产物已写入 {_display(dest)}（HTML 版：仅 web/ 的 css/js/html）")
    print("发布时用 NAVPANEL_WEB_DIR 指向该目录即可；React 版由 vite build 自带压缩，不受影响。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())