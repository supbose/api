"""生产环境启动 HTML 版：读压缩产物、单 worker、默认不开热重载。

与 `scripts/dev.py serve`（开发入口，带 --reload）分开，避免把开发模式带上线。

用法：
    python scripts/serve_html.py                 # 等价 npm run start:html
    python scripts/serve_html.py --port 8000 --host 127.0.0.1
    python scripts/serve_html.py --web-dir web   # 直接读源文件（排障用）
    python scripts/serve_html.py --no-check      # 跳过产物同步校验（产物由别处构建时用）
    python scripts/serve_html.py --reload        # 本地预览压缩产物的效果

行为：
- `NAVPANEL_FRONTEND` 固定为 html，`NAVPANEL_WEB_DIR` 指向产物目录（默认 dist/web）
- 启动前校验产物存在且与 `web/` 同步；发布包不带 `web/` 时只校验产物是否齐备，缺失或过期直接退出（退出码 1）
- 端口默认取 `PORT` 环境变量，其次 8000
"""

from __future__ import annotations

import argparse
import contextlib
import importlib.util
import io
import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_WEB_DIR = "dist/web"


def _load_minify_module():
    """按路径加载压缩脚本，复用它的同步判定，避免两套规则。"""
    path = BASE_DIR / "scripts" / "minify_web.py"
    spec = importlib.util.spec_from_file_location("minify_web", path)
    if spec is None or spec.loader is None:  # pragma: no cover - 文件缺失时才可能
        raise RuntimeError(f"找不到压缩脚本：{path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def resolve_web_dir(value: str) -> Path:
    """相对路径按项目根解析，与 app/config.py 的 WEB_DIR 规则一致。"""
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (BASE_DIR / path).resolve()


def validate(web_dir: Path, source_dir: Path, check_fresh: bool) -> list[str]:
    """返回阻塞启动的问题列表；空列表代表可以启动。"""
    if not web_dir.is_dir():
        return [f"产物目录不存在：{web_dir}（先执行 npm run build:html 或 python scripts/minify_web.py）"]
    problems: list[str] = []
    if not (web_dir / "index.html").is_file():
        problems.append(f"产物缺少 index.html：{web_dir}")
    if not check_fresh:
        return problems
    if not source_dir.is_dir():
        # 发布包里不带前端源（只带 dist/web），没有可比对的对象，产物存在即通过
        return problems

    minify = _load_minify_module()
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer), contextlib.redirect_stderr(buffer):
        code = minify.check(source_dir, web_dir)
    if code != 0:
        detail = " ".join(line.strip() for line in buffer.getvalue().splitlines() if line.strip())
        problems.append(f"产物与源文件不同步：{detail or '需要重新构建'}")
    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="以生产模式启动 HTML 版（压缩产物 + 单 worker）")
    parser.add_argument(
        "--web-dir",
        default=os.environ.get("NAVPANEL_WEB_DIR") or DEFAULT_WEB_DIR,
        help=f"HTML 静态目录，默认 {DEFAULT_WEB_DIR}（相对项目根）",
    )
    parser.add_argument("--source", default=str(BASE_DIR / "web"), help="源目录，默认 web/，用于校验产物是否最新")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址，默认 127.0.0.1（前面挂反向代理时保持）")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8000")), help="监听端口，默认 PORT 或 8000")
    parser.add_argument("--reload", action="store_true", help="开发用：改动即重载（生产不要开）")
    parser.add_argument("--no-check", action="store_true", help="跳过产物与源文件的同步校验")
    args = parser.parse_args(argv)

    web_dir = resolve_web_dir(args.web_dir)
    source_dir = resolve_web_dir(args.source)

    problems = validate(web_dir, source_dir, check_fresh=not args.no_check)
    if problems:
        print("启动中止：", file=sys.stderr)
        for item in problems:
            print(f"  - {item}", file=sys.stderr)
        return 1

    env = {
        **os.environ,
        "NAVPANEL_FRONTEND": "html",
        "NAVPANEL_WEB_DIR": str(web_dir),
    }
    command = [
        sys.executable,
        "-m",
        "uvicorn",
        "app.main:app",
        "--host",
        args.host,
        "--port",
        str(args.port),
        "--workers",
        "1",
    ]
    if args.reload:
        command.append("--reload")

    print(f"HTML 版生产启动：{web_dir}", flush=True)
    print(f"监听地址：http://{args.host}:{args.port}（热重载：{'开' if args.reload else '关'}）", flush=True)
    print(f"探活地址：http://{args.host}:{args.port}/api/health", flush=True)
    os.chdir(BASE_DIR)
    try:
        os.execvpe(sys.executable, command, env)
    except OSError as exc:  # pragma: no cover - 仅在解释器不可执行时触发
        print(f"启动 uvicorn 失败：{exc}", file=sys.stderr)
        return 1
    return 0  # pragma: no cover - exec 成功后不会返回


if __name__ == "__main__":
    raise SystemExit(main())